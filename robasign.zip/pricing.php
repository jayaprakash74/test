<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: /");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en-US" dir="ltr">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <!-- ===============================================-->
    <!--    Document Title-->
    <!-- ===============================================-->
    <title>Pricing | Robasign</title>


    <!-- ===============================================-->
    <!--    Favicons-->
    <!-- ===============================================-->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/favicon-16x16.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicons/favicon.ico">
    <link rel="manifest" href="assets/img/favicons/manifest.json">
    <meta name="msapplication-TileImage" content="assets/img/favicons/mstile-150x150.png">
    <meta name="theme-color" content="#ffffff">


    <!-- ===============================================-->
    <!--    Stylesheets-->
    <!-- ===============================================-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700%7cPoppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="assets/lib/semantic-ui-accordion/accordion.min.css" rel="stylesheet">
    <link href="assets/lib/semantic-ui-transition/transition.min.css" rel="stylesheet">
    <link href="assets/css/theme.css" rel="stylesheet">

  </head>


  <body>

    <!-- ===============================================-->
    <!--    Main Content-->
    <!-- ===============================================-->
    <main class="main" id="top">


      <div class="container-fluid">
        <?php include 'menu.php'; ?>
        <div class="content">
          <?php include 'header_bar.php'; ?>
          <div class="card overflow-hidden mb-3">
            <div class="bg-holder d-none d-lg-block bg-card" style="background-image:url(assets/img/illustrations/corner-4.png);">
            </div>
            <!--/.bg-holder-->

            <div class="card-body position-relative">
              <h6 class="text-600">Free for 30 days</h6>
              <h2>For teams of all sizes, in the cloud</h2>
              <p class="mb-0">Get the power, control, and customization you need to manage your<br class="d-none d-md-block"> team’s and organization’s projects.</p><a class="btn btn-link pl-0 btn-sm mt-3" href="#!"> Have questions? Chat with us</a>
            </div>
          </div>
          <div class="card mb-3">
            <div class="card-body">
              <div class="row no-gutters">
                <div class="col-12 mb-3">
                  <div class="row justify-content-center justify-content-sm-between">
                    <div class="col-sm-auto text-center">
                      <h5 class="d-inline-block">Build Annually</h5><span class="badge badge-soft-success badge-pill ml-2">Save 25%</span>
                    </div>
                    <div class="col-sm-auto d-flex flex-center fs--1 mt-1 mt-sm-0">
                      <label class="mr-2 mb-0" for="customSwitch1">Monthly</label>
                      <div class="custom-control custom-switch">
                        <input class="custom-control-input" id="customSwitch1" type="checkbox" checked>
                        <label class="custom-control-label" for="customSwitch1">Yearly</label>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="col-lg-4 border-top border-bottom">
                  <div class="h-100">
                    <div class="text-center p-4">
                      <h3 class="font-weight-normal my-0">Residential</h3>
                      <p class="mt-3">For teams that need to create project plans with confidence.</p>
                      <h2 class="font-weight-medium my-4"> <sup class="font-weight-normal fs-2 mr-1">&dollar;</sup>10<small class="fs--1 text-700">/ 5 Agents</small></h2><a class="btn btn-outline-primary" href="pages/billing.html">Start free trial</a>
                    </div>
                    <hr class="border-bottom-0 m-0">
                    <div class="text-left px-sm-4 py-4">
                      <h5 class="font-weight-medium fs-0">Track team projects with free:</h5>
                      <ul class="list-unstyled mt-3">
                        <li class="py-1"><span class="mr-2 fas fa-check text-success"></span> Timeline</li>
                        <li class="py-1"><span class="mr-2 fas fa-check text-success"></span> Advanced Search</li>
                        <li class="py-1"><span class="mr-2 fas fa-check text-success"></span> Custom fields<span class="badge badge-soft-success badge-pill ml-1">New</span></li>
                        <li class="py-1"><span class="mr-2 fas fa-check text-success"></span> Task dependencies</li>
                        <li class="py-1"><span class="mr-2 fas fa-check text-success"></span> Private teams & projects</li>
                      </ul><a class="btn btn-link" href="#">More about Single</a>
                    </div>
                  </div>
                </div>
                <div class="col-lg-4 border-top border-bottom">
                  <div class="h-100" style="background-color: rgba(115, 255, 236, 0.18)">
                    <div class="text-center p-4">
                      <h3 class="font-weight-normal my-0">Commercial</h3>
                      <p class="mt-3">For teams and companies that need to manage work across initiatives.</p>
                      <h2 class="font-weight-medium my-4"> <sup class="font-weight-normal fs-2 mr-1">&dollar;</sup>20<small class="fs--1 text-700">/ 10 Agents</small></h2><a class="btn btn-primary" href="pages/billing.html">Get Business</a>
                    </div>
                    <hr class="border-bottom-0 m-0">
                    <div class="text-left px-3 px-sm-4 py-4">
                      <h5 class="font-weight-medium fs-0">Everything in Premium, plus:</h5>
                      <ul class="list-unstyled mt-3">
                        <li class="py-1"><span class="mr-2 fas fa-check text-success"></span> Portfolios </li>
                        <li class="py-1"><span class="mr-2 fas fa-check text-success"></span> Lock custom fields </li>
                        <li class="py-1"><span class="mr-2 fas fa-check text-success"></span> Onboarding plan</li>
                        <li class="py-1"><span class="mr-2 fas fa-check text-success"></span> Resource Management</li>
                        <li class="py-1"><span class="mr-2 fas fa-check text-success"></span> Lock custom fields</li>
                      </ul><a class="btn btn-link" href="#">More about Business</a>
                    </div>
                  </div>
                </div>
                <div class="col-lg-4 border-top border-bottom">
                  <div class="h-100">
                    <div class="text-center p-4">
                      <h3 class="font-weight-normal my-0">Bridging</h3>
                      <p class="mt-3">For organizations that need additional security and support.</p>
                      <h2 class="font-weight-medium my-4"> <sup class="font-weight-normal fs-2 mr-1">&dollar;</sup>40<small class="fs--1 text-700">/ 15 Agents</small></h2><a class="btn btn-outline-primary" href="pages/billing.html">Purchase</a>
                    </div>
                    <hr class="border-bottom-0 m-0">
                    <div class="text-left px-sm-4 py-4">
                      <h5 class="font-weight-medium fs-0">Everything in Business, plus:</h5>
                      <ul class="list-unstyled mt-3">
                        <li class="py-1"><span class="mr-2 fas fa-check text-success"></span> Portfolios </li>
                        <li class="py-1"><span class="mr-2 fas fa-check text-success"></span> Tags<span class="badge badge-soft-primary badge-pill ml-1">Coming soon</span></li>
                        <li class="py-1"><span class="mr-2 fas fa-check text-success"></span> Onboarding plan</li>
                        <li class="py-1"><span class="mr-2 fas fa-check text-success"></span> Resource Management</li>
                      </ul><a class="btn btn-link" href="#">More about Extended</a>
                    </div>
                  </div>
                </div>
                <div class="col-12 text-center">
                  <h5 class="mt-5">Looking for personal or small team task management?</h5>
                  <p class="fs-1">Try the <a href="#">basic version</a> of Falcon</p>
                </div>
              </div>
            </div>
          </div>
          <div class="card">
            <div class="card-header">
              <h4 class="text-center mb-0">Frequently asked questions</h4>
            </div>
            <div class="card-body bg-light">
              <div class="ui styled fluid accordion" data-options='{"exclusive":false}'>
                <div class="active title"><i class="dropdown icon"></i>
                  <h5 class="d-inline-block fs-0">How long do payouts take?</h5>
                </div>
                <div class="active content">
                  <p>Once you’re set up, payouts arrive in your bank account on a 2-day rolling basis. Or you can opt to receive payouts weekly or monthly</p>
                </div>
                <div class="title"><i class="dropdown icon"></i>
                  <h5 class="d-inline-block fs-0">How do refunds work?</h5>
                </div>
                <div class="content">
                  <p>You can issue either partial or full refunds. There are no fees to refund a charge, but the fees from the original charge are not returned.</p>
                </div>
                <div class="title"><i class="dropdown icon"></i>
                  <h5 class="d-inline-block fs-0">How much do disputes costs?</h5>
                </div>
                <div class="content">
                  <p>Disputed payments (also known as chargebacks) incur a $15.00 fee. If the customer’s bank resolves the dispute in your favor, the fee is fully refunded</p>
                </div>
                <div class="title"><i class="dropdown icon"></i>
                  <h5 class="d-inline-block fs-0">Is there a fee to use Apple Pay or Google Pay?</h5>
                </div>
                <div class="content">
                  <p>There are no additional fees for using our mobile SDKs or to accept payments using consumer wallets like Apple Pay or Google Pay.</p>
                </div>
              </div>
            </div>
          </div>
          <footer>
            <div class="row no-gutters justify-content-between fs--1 mt-4 mb-3">
              <div class="col-12 col-sm-auto text-center">
                <p class="mb-0 text-600">Thank you for creating with Falcon <span class="d-none d-sm-inline-block">| </span><br class="d-sm-none" /> 2019 &copy; <a href="https://themewagon.com">Themewagon</a></p>
              </div>
              <div class="col-12 col-sm-auto text-center">
                <p class="mb-0 text-600">v1.8.1</p>
              </div>
            </div>
          </footer>
        </div>
        <div class="modal fade" id="authentication-modal" tabindex="-1" role="dialog" aria-labelledby="authentication-modal-label" aria-hidden="true">
          <div class="modal-dialog mt-6" role="document">
            <div class="modal-content border-0">
              <div class="modal-header px-5 text-white position-relative modal-shape-header">
                <div class="position-relative z-index-1">
                  <div>
                    <h4 class="mb-0 text-white" id="authentication-modal-label">Register</h4>
                    <p class="fs--1 mb-0">Please create your free Falcon account</p>
                  </div>
                </div>
                <button class="close text-white position-absolute t-0 r-0 mt-1 mr-1" data-dismiss="modal" aria-label="Close"><span class="font-weight-light" aria-hidden="true">&times;</span></button>
              </div>
              <div class="modal-body py-4 px-5">
                <form>
                  <div class="form-group">
                    <label for="modal-auth-name">Name</label>
                    <input class="form-control" type="text" id="modal-auth-name" />
                  </div>
                  <div class="form-group">
                    <label for="modal-auth-email">Email</label>
                    <input class="form-control" type="email" id="modal-auth-email" />
                  </div>
                  <div class="form-row">
                    <div class="form-group col-6">
                      <label for="modal-auth-password">Password</label>
                      <input class="form-control" type="password" id="modal-auth-password" />
                    </div>
                    <div class="form-group col-6">
                      <label for="modal-auth-confirm-password">Confirm Password</label>
                      <input class="form-control" type="password" id="modal-auth-confirm-password" />
                    </div>
                  </div>
                  <div class="custom-control custom-checkbox">
                    <input class="custom-control-input" type="checkbox" id="modal-auth-register-checkbox" />
                    <label class="custom-control-label" for="modal-auth-register-checkbox">I accept the <a href="#!">terms </a>and <a href="#!">privacy policy</a></label>
                  </div>
                  <div class="form-group">
                    <button class="btn btn-primary btn-block mt-3" type="submit" name="submit">Register</button>
                  </div>
                </form>
                <div class="w-100 position-relative mt-5">
                  <hr class="text-300" />
                  <div class="position-absolute absolute-centered t-0 px-3 bg-white text-sans-serif fs--1 text-500 text-nowrap">or sign-up with</div>
                </div>
                <div class="form-group mb-0">
                  <div class="row no-gutters">
                    <div class="col-sm-6 pr-sm-1"><a class="btn btn-outline-google-plus btn-sm btn-block mt-2" href="#"><span class="fab fa-google-plus-g mr-2" data-fa-transform="grow-8"></span> google</a></div>
                    <div class="col-sm-6 pl-sm-1"><a class="btn btn-outline-facebook btn-sm btn-block mt-2" href="#"><span class="fab fa-facebook mr-2" data-fa-transform="grow-8"></span> facebook</a></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
    <!-- ===============================================-->
    <!--    End of Main Content-->
    <!-- ===============================================-->




    <!-- ===============================================-->
    <!--    JavaScripts-->
    <!-- ===============================================-->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.js"></script>
    <script src="assets/lib/stickyfilljs/stickyfill.min.js"></script>
    <script src="assets/lib/sticky-kit/sticky-kit.min.js"></script>
    <script src="assets/lib/is_js/is.min.js"></script>
    <script src="assets/lib/@fortawesome/all.min.js"></script>
    <script src="assets/lib/semantic-ui-accordion/accordion.min.js"></script>
    <script src="assets/lib/semantic-ui-transition/transition.min.js"></script>
    <script src="assets/js/theme.js"></script>

  </body>

</html>
