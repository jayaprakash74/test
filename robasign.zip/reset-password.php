<?php
// Include config file
require_once "config.php";
?>
<?php
// Processing form data when form is submitted
////if($_SERVER["REQUEST_METHOD"] == "POST"){

	$verify_token = $_GET['q'];
	
	// prepare and bind
	$stmt = "SELECT * FROM registration WHERE verify_token = '$verify_token'";
	
	$result = mysqli_query($link, $stmt);
	if (mysqli_num_rows($result) > 0) {
		while ($row = mysqli_fetch_assoc($result)) {
			if ($verify_token == $row["verify_token"]) {
?>
			
<!DOCTYPE html>
<html lang="en-US" dir="ltr">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <!-- ===============================================-->
    <!--    Document Title-->
    <!-- ===============================================-->
    <title>Reset Password | Robasign</title>


    <!-- ===============================================-->
    <!--    Favicons-->
    <!-- ===============================================-->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/favicon-16x16.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicons/favicon.ico">
    <link rel="manifest" href="assets/img/favicons/manifest.json">
    <meta name="msapplication-TileImage" content="assets/img/favicons/mstile-150x150.png">
    <meta name="theme-color" content="#ffffff">


    <!-- ===============================================-->
    <!--    Stylesheets-->
    <!-- ===============================================-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700%7cPoppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="assets/css/theme.css" rel="stylesheet">

  </head>


  <body>

    <!-- ===============================================-->
    <!--    Main Content-->
    <!-- ===============================================-->
    <main class="main" id="top">
      <div class="container-fluid">
        <div class="row min-vh-100 flex-center no-gutters">
          <div class="col-lg-8 col-xxl-5 py-3"><img class="bg-auth-circle-shape" src="assets/img/illustrations/bg-shape.png" alt="" width="250"><img class="bg-auth-circle-shape-2" src="assets/img/illustrations/shape-1.png" alt="" width="150">
            <div class="card overflow-hidden z-index-1">
              <div class="card-body p-0">
                <div class="row no-gutters h-100">
                  <div class="col-md-5 text-white text-center bg-card-gradient">
                    <div class="position-relative p-4 pt-md-5 pb-md-7">
                      <div class="bg-holder bg-auth-card-shape" style="background-image:url(assets/img/illustrations/half-circle.png);">
                      </div>
                      <!--/.bg-holder-->

                      <div class="z-index-1 position-relative"><a class="text-white mb-4 text-sans-serif font-weight-extra-bold fs-4 d-inline-block" href="index">Robasign</a>
                        <p class="text-100">With the power of Robasign, you can now focus only on functionaries for your digital products, while leaving the UI design on us!</p>
                      </div>
                    </div>
                    <div class="mt-3 mb-4 mt-md-4 mb-md-5">
                      <p class="mb-0 mt-4 mt-md-5 fs--1 font-weight-semi-bold text-300">Read our <a class="text-underline text-300" href="#!">terms</a> and <a class="text-underline text-300" href="#!">conditions </a></p>
                    </div>
                  </div>
                  <div class="col-md-7 d-flex flex-center">
                    <div class="p-4 p-md-5 flex-grow-1">
                      <h3>Reset password</h3>
		<?php			  
					  // Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
	
	// prepare and bind
	$stmt = $link->prepare("UPDATE registration (hashed_password)
			VALUES (?) WHERE verify_token = ?");
	
	$stmt->bind_param("ss", $hashed_password, $verify_token);
	
	$fname = trim($_POST["password"]);
}
	
	?>
					  
                      <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" class="mt-3">
                        <div class="form-group">
                          <label for="card-reset-password">Password</label>
                          <input class="form-control" type="password" name="password" id="password" required />
                        </div>
                        <div class="form-group">
                          <label for="card-reset-confirm-password">Confirm Password</label>
                          <input class="form-control" type="password" name="confirmPassword" id="confirmPassword" required />
                        </div>
                        <button class="btn btn-primary btn-block mt-3" type="submit" name="submit">Set password</button>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
    <!-- ===============================================-->
    <!--    End of Main Content-->
    <!-- ===============================================-->




    <!-- ===============================================-->
    <!--    JavaScripts-->
    <!-- ===============================================-->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.js"></script>
    <script src="assets/lib/stickyfilljs/stickyfill.min.js"></script>
    <script src="assets/lib/sticky-kit/sticky-kit.min.js"></script>
    <script src="assets/lib/is_js/is.min.js"></script>
    <script src="assets/lib/@fortawesome/all.min.js"></script>
    <script src="assets/js/theme.js"></script>

  </body>

</html>

<?php
			} else {
				header("location: /");
				exit;
			}
		}
	} else {
		header("location: /");
		exit;
	}
	

////}
?>