<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: /");
    exit;
}

// Include config file
require_once "config.php";

?>

<!DOCTYPE html>
<html lang="en-US" dir="ltr">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <!-- ===============================================-->
    <!--    Document Title-->
    <!-- ===============================================-->
    <title>Edit Application | Robasign</title>


    <!-- ===============================================-->
    <!--    Favicons-->
    <!-- ===============================================-->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/favicon-16x16.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicons/favicon.ico">
    <link rel="manifest" href="assets/img/favicons/manifest.json">
    <meta name="msapplication-TileImage" content="assets/img/favicons/mstile-150x150.png">
    <meta name="theme-color" content="#ffffff">


    <!-- ===============================================-->
    <!--    Stylesheets-->
    <!-- ===============================================-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700%7cPoppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="assets/lib/select2/select2.min.css" rel="stylesheet">
    <link href="assets/lib/flatpickr/flatpickr.min.css" rel="stylesheet">
    <link href="assets/css/theme.css" rel="stylesheet">

  </head>


  <body>

    <!-- ===============================================-->
    <!--    Main Content-->
    <!-- ===============================================-->
    <main class="main" id="top">
      <div class="container-fluid">
        <?php include 'menu.php'; ?>
        <div class="content">
          <?php include 'header_bar.php'; ?>
          <div class="card mb-3">
            <div class="card-body">
              <div class="row justify-content-between align-items-center">
                <div class="col-md">
                  <h5 class="mb-2 mb-md-0">Edit Application</h5>
                </div>
                <div class="col-auto">
                </div>
              </div>
            </div>
          </div>
          
<?php	 	 
	
if (isset($_POST['submit'])) {
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
	
	// prepare and bind
	$stmt = $link->prepare("UPDATE rs_applications SET firstname = ?, lastname = ?, mobile = ?, email = ?, address1 = ?, address2 = ?, city = ?, state = ?, zip = ?, description = ?, product_type = ?, rs_users_id = ?, application_status = ? WHERE id = ?");
	
	$stmt->bind_param("ssssssssssssss", $fname, $lname, $mobile, $email, $address1, $address2, $city, $county, $postcode, $description, $productType, $user_id, $application_status, $app_id);
	
	$fname = trim($_POST["first-name"]);
	$lname = trim($_POST["last-name"]);
	$mobile = trim($_POST["mobile"]);
	$email = trim($_POST["email"]);
	$address1 = trim($_POST["address1"]);
	$address2 = trim($_POST["address2"]);
	$city = trim($_POST["city"]);
	$county = trim($_POST["county"]);
	$postcode = trim($_POST["post-code"]);
	$description = trim($_POST["description"]);
	$productType = trim($_POST["product-type"]);
	$user_id = trim($_SESSION['id']);
	$application_status = "InProgress";
	$app_id = $_GET['q'];

	
	if ($stmt->execute()) {

	?>
	<div id="messages" class="alert alert-success alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		<div id="messages_content"><?php echo"Application ID: $app_id Submitted Succesfully"; ?></div>
    </div>
	<?php 
	    
	
	} else {
		
		?>
		
		<div id="messages" class="alert alert-danger alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <div id="messages_content"><?php echo"Submitting Application ID: $app_id Failed"; ?></div>
        </div>
<?php
	}

		$filesToZip = array();
	$output_dir = "Main Folder/Not Started Applications/";
	
	if($_FILES['bs1']['name'] != '' && $_FILES['bs1']['size'] != 0) {
            $RandomNum   = time();
			$bs1 = "bankstatement1";
        
            $ImageName      = str_replace(' ','-',strtolower($_FILES['bs1']['name']));
            $ImageType      = $_FILES['bs1']['type'];
         
            $ImageExt 		= substr($ImageName, strrpos($ImageName, '.'));
            $ImageExt       = str_replace('.','',$ImageExt);
            $ImageName      = preg_replace("/\.[^.\s]{3,4}$/", "", $ImageName);
            $NewImageName 	= $bs1.'-'.$ImageName.'.'.$ImageExt;
            
            $ret[$NewImageName]= $output_dir.$NewImageName;
			array_push($filesToZip, $ImageName);
            
			if (!file_exists($output_dir . $app_id)) {
				@mkdir($output_dir . $app_id, 0777);
			}
                        
            move_uploaded_file($_FILES["bs1"]["tmp_name"],$output_dir.$app_id."/".$NewImageName );
			
			$ins_bs1 = $link->prepare("UPDATE rs_applications SET bankstatement1 = ? WHERE id = ?");
			$ins_bs1->bind_param("ss", $NewImageName, $app_id);
			$ins_bs1->execute();
	}
	
		if($_FILES['ps1']['name'] != '' && $_FILES['ps1']['size'] != 0) {
            $RandomNum   = time();
			$ps1 = "payslip1";
        
            $ImageName      = str_replace(' ','-',strtolower($_FILES['ps1']['name']));
            $ImageType      = $_FILES['ps1']['type'];
         
            $ImageExt 		= substr($ImageName, strrpos($ImageName, '.'));
            $ImageExt       = str_replace('.','',$ImageExt);
            $ImageName      = preg_replace("/\.[^.\s]{3,4}$/", "", $ImageName);
            $NewImageName 	= $ps1.'-'.$ImageName.'.'.$ImageExt;
            
            $ret[$NewImageName]= $output_dir.$NewImageName;
			array_push($filesToZip, $ImageName);
            
			if (!file_exists($output_dir . $app_id)) {
				@mkdir($output_dir . $app_id, 0777);
			}
                        
            move_uploaded_file($_FILES["ps1"]["tmp_name"],$output_dir.$app_id."/".$NewImageName );
			
			$ins_ps1 = $link->prepare("UPDATE rs_applications SET payslip1 = ? WHERE id = ?");
			$ins_ps1->bind_param("ss", $NewImageName, $app_id);
			$ins_ps1->execute();
		}
	
		if($_FILES['bs2']['name'] != '' && $_FILES['bs2']['size'] != 0) {
            $RandomNum   = time();
			$bs2 = "bankstatement2";
        
            $ImageName      = str_replace(' ','-',strtolower($_FILES['bs2']['name']));
            $ImageType      = $_FILES['bs2']['type'];
         
            $ImageExt 		= substr($ImageName, strrpos($ImageName, '.'));
            $ImageExt       = str_replace('.','',$ImageExt);
            $ImageName      = preg_replace("/\.[^.\s]{3,4}$/", "", $ImageName);
            $NewImageName 	= $bs2.'-'.$ImageName.'.'.$ImageExt;
            
            $ret[$NewImageName]= $output_dir.$NewImageName;
			array_push($filesToZip, $ImageName);
            
			if (!file_exists($output_dir . $app_id)) {
				@mkdir($output_dir . $app_id, 0777);
			}
                        
            move_uploaded_file($_FILES["bs2"]["tmp_name"],$output_dir.$app_id."/".$NewImageName );
			
			$ins_bs2 = $link->prepare("UPDATE rs_applications SET bankstatement2 = ? WHERE id = ?");
			$ins_bs2->bind_param("ss", $NewImageName, $app_id);
			$ins_bs2->execute();
		}
	
		if($_FILES['ps2']['name'] != '' && $_FILES['ps2']['size'] != 0) {
            $RandomNum   = time();
			$ps2 = "payslip2";
        
            $ImageName      = str_replace(' ','-',strtolower($_FILES['ps2']['name']));
            $ImageType      = $_FILES['ps2']['type'];
         
            $ImageExt 		= substr($ImageName, strrpos($ImageName, '.'));
            $ImageExt       = str_replace('.','',$ImageExt);
            $ImageName      = preg_replace("/\.[^.\s]{3,4}$/", "", $ImageName);
            $NewImageName 	= $ps2.'-'.$ImageName.'.'.$ImageExt;
            
            $ret[$NewImageName]= $output_dir.$NewImageName;
			array_push($filesToZip, $ImageName);
            
			if (!file_exists($output_dir . $app_id)) {
				@mkdir($output_dir . $app_id, 0777);
			}
                        
            move_uploaded_file($_FILES["ps2"]["tmp_name"],$output_dir.$app_id."/".$NewImageName );
			
			$ins_ps2 = $link->prepare("UPDATE rs_applications SET payslip2 = ? WHERE id = ?");
			$ins_ps2->bind_param("ss", $NewImageName, $app_id);
			$ins_ps2->execute();
		}
	
			if($_FILES['bs3']['name'] != '' && $_FILES['bs3']['size'] != 0) {
            $RandomNum   = time();
			$bs3 = "bankstatement3";
        
            $ImageName      = str_replace(' ','-',strtolower($_FILES['bs3']['name']));
            $ImageType      = $_FILES['bs3']['type'];
         
            $ImageExt 		= substr($ImageName, strrpos($ImageName, '.'));
            $ImageExt       = str_replace('.','',$ImageExt);
            $ImageName      = preg_replace("/\.[^.\s]{3,4}$/", "", $ImageName);
            $NewImageName 	= $bs3.'-'.$ImageName.'.'.$ImageExt;
            
            $ret[$NewImageName]= $output_dir.$NewImageName;
			array_push($filesToZip, $ImageName);
            
			if (!file_exists($output_dir . $app_id)) {
				@mkdir($output_dir . $app_id, 0777);
			}
                        
            move_uploaded_file($_FILES["bs3"]["tmp_name"],$output_dir.$app_id."/".$NewImageName );
			
			$ins_bs3 = $link->prepare("UPDATE rs_applications SET bankstatement3 = ? WHERE id = ?");
			$ins_bs3->bind_param("ss", $NewImageName, $app_id);
			$ins_bs3->execute();
		}
	
	
		if($_FILES['ps3']['name'] != '' && $_FILES['ps3']['size'] != 0) {
            $RandomNum   = time();
			$ps3 = "payslip3";
        
            $ImageName      = str_replace(' ','-',strtolower($_FILES['ps3']['name']));
            $ImageType      = $_FILES['ps3']['type'];
         
            $ImageExt 		= substr($ImageName, strrpos($ImageName, '.'));
            $ImageExt       = str_replace('.','',$ImageExt);
            $ImageName      = preg_replace("/\.[^.\s]{3,4}$/", "", $ImageName);
            $NewImageName 	= $ps3.'-'.$ImageName.'.'.$ImageExt;
            
            $ret[$NewImageName]= $output_dir.$NewImageName;
			array_push($filesToZip, $ImageName);
            
			if (!file_exists($output_dir . $app_id)) {
				@mkdir($output_dir . $app_id, 0777);
			}
                        
            move_uploaded_file($_FILES["ps3"]["tmp_name"],$output_dir.$app_id."/".$NewImageName );
			$ins_ps3 = $link->prepare("UPDATE rs_applications SET payslip3 = ? WHERE id = ?");
			$ins_ps3->bind_param("ss", $NewImageName, $app_id);
			$ins_ps3->execute();
			
		}
	
	/************* *********** **************/
	/************* ZIP ARCHIVE **************/
	/************* *********** **************/
	
	$zip = new ZipArchive;
    $download = "Main Folder/In Progress Applications/".$app_id.".zip";
    $zip->open($download, ZipArchive::CREATE);
    foreach (glob("Main Folder/Not Started Applications/$app_id/*.pdf") as $file) {
        $new_filename = substr($file,strrpos($file,'/') + 1);
		$zip->addFile($file,$new_filename);
    }
    $zip->close();
	
	$files = glob("Main Folder/Not Started Applications/$app_id/*");
	foreach($files as $file){
		if(is_file($file))
			unlink($file);
		}

	$dirname2 = "Main Folder/Not Started Applications/$app_id";
	if (file_exists($dirname2)) {
		rmdir($dirname2);
	}

	//$stmt->close();
	//$link->close();
}
}
?>

<?php	 	 
	
if (isset($_POST['save'])) {
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
	
	// prepare and bind
	$stmt = $link->prepare("UPDATE rs_applications SET firstname = ?, lastname = ?, mobile = ?, email = ?, address1 = ?, address2 = ?, city = ?, state = ?, zip = ?, description = ?, product_type = ?, rs_users_id = ?, application_status = ? WHERE id = ?");
	
	$stmt->bind_param("ssssssssssssss", $fname, $lname, $mobile, $email, $address1, $address2, $city, $county, $postcode, $description, $productType, $user_id, $application_status, $app_id);
	
	$fname = trim($_POST["first-name"]);
	$lname = trim($_POST["last-name"]);
	$mobile = trim($_POST["mobile"]);
	$email = trim($_POST["email"]);
	$address1 = trim($_POST["address1"]);
	$address2 = trim($_POST["address2"]);
	$city = trim($_POST["city"]);
	$county = trim($_POST["county"]);
	$postcode = trim($_POST["post-code"]);
	$description = trim($_POST["description"]);
	$productType = trim($_POST["product-type"]);
	$user_id = trim($_SESSION['id']);
	$application_status = "Not Submitted";
	$app_id = $_GET['q'];

	
	if ($stmt->execute()) {

	?>
	<div id="messages" class="alert alert-success alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		<div id="messages_content"><?php echo"Application ID: $app_id Updated Succesfully"; ?></div>
    </div>
	<?php 
	    
	
	} else {
		
		?>
		
		<div id="messages" class="alert alert-danger alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <div id="messages_content"><?php echo"Updating Application ID: $app_id Failed"; ?></div>
        </div>
<?php
	}

		$filesToZip = array();
	$output_dir = "Main Folder/Not Started Applications/";
	
	if($_FILES['bs1']['name'] != '' && $_FILES['bs1']['size'] != 0) {
            $RandomNum   = time();
			$bs1 = "bankstatement1";
        
            $ImageName      = str_replace(' ','-',strtolower($_FILES['bs1']['name']));
            $ImageType      = $_FILES['bs1']['type'];
         
            $ImageExt 		= substr($ImageName, strrpos($ImageName, '.'));
            $ImageExt       = str_replace('.','',$ImageExt);
            $ImageName      = preg_replace("/\.[^.\s]{3,4}$/", "", $ImageName);
            $NewImageName 	= $bs1.'-'.$ImageName.'.'.$ImageExt;
            
            $ret[$NewImageName]= $output_dir.$NewImageName;
			array_push($filesToZip, $ImageName);
            
			if (!file_exists($output_dir . $app_id)) {
				@mkdir($output_dir . $app_id, 0777);
			}
                        
            move_uploaded_file($_FILES["bs1"]["tmp_name"],$output_dir.$app_id."/".$NewImageName );
			
			$ins_bs1 = $link->prepare("UPDATE rs_applications SET bankstatement1 = ? WHERE id = ?");
			$ins_bs1->bind_param("ss", $NewImageName, $app_id);
			$ins_bs1->execute();
	}
	
		if($_FILES['ps1']['name'] != '' && $_FILES['ps1']['size'] != 0) {
            $RandomNum   = time();
			$ps1 = "payslip1";
        
            $ImageName      = str_replace(' ','-',strtolower($_FILES['ps1']['name']));
            $ImageType      = $_FILES['ps1']['type'];
         
            $ImageExt 		= substr($ImageName, strrpos($ImageName, '.'));
            $ImageExt       = str_replace('.','',$ImageExt);
            $ImageName      = preg_replace("/\.[^.\s]{3,4}$/", "", $ImageName);
            $NewImageName 	= $ps1.'-'.$ImageName.'.'.$ImageExt;
            
            $ret[$NewImageName]= $output_dir.$NewImageName;
			array_push($filesToZip, $ImageName);
            
			if (!file_exists($output_dir . $app_id)) {
				@mkdir($output_dir . $app_id, 0777);
			}
                        
            move_uploaded_file($_FILES["ps1"]["tmp_name"],$output_dir.$app_id."/".$NewImageName );
			
			$ins_ps1 = $link->prepare("UPDATE rs_applications SET payslip1 = ? WHERE id = ?");
			$ins_ps1->bind_param("ss", $NewImageName, $app_id);
			$ins_ps1->execute();
		}
	
		if($_FILES['bs2']['name'] != '' && $_FILES['bs2']['size'] != 0) {
            $RandomNum   = time();
			$bs2 = "bankstatement2";
        
            $ImageName      = str_replace(' ','-',strtolower($_FILES['bs2']['name']));
            $ImageType      = $_FILES['bs2']['type'];
         
            $ImageExt 		= substr($ImageName, strrpos($ImageName, '.'));
            $ImageExt       = str_replace('.','',$ImageExt);
            $ImageName      = preg_replace("/\.[^.\s]{3,4}$/", "", $ImageName);
            $NewImageName 	= $bs2.'-'.$ImageName.'.'.$ImageExt;
            
            $ret[$NewImageName]= $output_dir.$NewImageName;
			array_push($filesToZip, $ImageName);
            
			if (!file_exists($output_dir . $app_id)) {
				@mkdir($output_dir . $app_id, 0777);
			}
                        
            move_uploaded_file($_FILES["bs2"]["tmp_name"],$output_dir.$app_id."/".$NewImageName );
			
			$ins_bs2 = $link->prepare("UPDATE rs_applications SET bankstatement2 = ? WHERE id = ?");
			$ins_bs2->bind_param("ss", $NewImageName, $app_id);
			$ins_bs2->execute();
		}
	
		if($_FILES['ps2']['name'] != '' && $_FILES['ps2']['size'] != 0) {
            $RandomNum   = time();
			$ps2 = "payslip2";
        
            $ImageName      = str_replace(' ','-',strtolower($_FILES['ps2']['name']));
            $ImageType      = $_FILES['ps2']['type'];
         
            $ImageExt 		= substr($ImageName, strrpos($ImageName, '.'));
            $ImageExt       = str_replace('.','',$ImageExt);
            $ImageName      = preg_replace("/\.[^.\s]{3,4}$/", "", $ImageName);
            $NewImageName 	= $ps2.'-'.$ImageName.'.'.$ImageExt;
            
            $ret[$NewImageName]= $output_dir.$NewImageName;
			array_push($filesToZip, $ImageName);
            
			if (!file_exists($output_dir . $app_id)) {
				@mkdir($output_dir . $app_id, 0777);
			}
                        
            move_uploaded_file($_FILES["ps2"]["tmp_name"],$output_dir.$app_id."/".$NewImageName );
			
			$ins_ps2 = $link->prepare("UPDATE rs_applications SET payslip2 = ? WHERE id = ?");
			$ins_ps2->bind_param("ss", $NewImageName, $app_id);
			$ins_ps2->execute();
		}
	
			if($_FILES['bs3']['name'] != '' && $_FILES['bs3']['size'] != 0) {
            $RandomNum   = time();
			$bs3 = "bankstatement3";
        
            $ImageName      = str_replace(' ','-',strtolower($_FILES['bs3']['name']));
            $ImageType      = $_FILES['bs3']['type'];
         
            $ImageExt 		= substr($ImageName, strrpos($ImageName, '.'));
            $ImageExt       = str_replace('.','',$ImageExt);
            $ImageName      = preg_replace("/\.[^.\s]{3,4}$/", "", $ImageName);
            $NewImageName 	= $bs3.'-'.$ImageName.'.'.$ImageExt;
            
            $ret[$NewImageName]= $output_dir.$NewImageName;
			array_push($filesToZip, $ImageName);
            
			if (!file_exists($output_dir . $app_id)) {
				@mkdir($output_dir . $app_id, 0777);
			}
                        
            move_uploaded_file($_FILES["bs3"]["tmp_name"],$output_dir.$app_id."/".$NewImageName );
			
			$ins_bs3 = $link->prepare("UPDATE rs_applications SET bankstatement3 = ? WHERE id = ?");
			$ins_bs3->bind_param("ss", $NewImageName, $app_id);
			$ins_bs3->execute();
		}
	
	
		if($_FILES['ps3']['name'] != '' && $_FILES['ps3']['size'] != 0) {
            $RandomNum   = time();
			$ps3 = "payslip3";
        
            $ImageName      = str_replace(' ','-',strtolower($_FILES['ps3']['name']));
            $ImageType      = $_FILES['ps3']['type'];
         
            $ImageExt 		= substr($ImageName, strrpos($ImageName, '.'));
            $ImageExt       = str_replace('.','',$ImageExt);
            $ImageName      = preg_replace("/\.[^.\s]{3,4}$/", "", $ImageName);
            $NewImageName 	= $ps3.'-'.$ImageName.'.'.$ImageExt;
            
            $ret[$NewImageName]= $output_dir.$NewImageName;
			array_push($filesToZip, $ImageName);
            
			if (!file_exists($output_dir . $app_id)) {
				@mkdir($output_dir . $app_id, 0777);
			}
                        
            move_uploaded_file($_FILES["ps3"]["tmp_name"],$output_dir.$app_id."/".$NewImageName );
			$ins_ps3 = $link->prepare("UPDATE rs_applications SET payslip3 = ? WHERE id = ?");
			$ins_ps3->bind_param("ss", $NewImageName, $app_id);
			$ins_ps3->execute();
			
		}

	//$stmt->close();
	//$link->close();
}
}
function add3dots($string, $repl, $limit) 
{
  if(strlen($string) > $limit) 
  {
    return substr($string, 0, $limit) . $repl; 
  }
  else 
  {
    return $string;
  }
}
?>

				<?php	
				$app_id = $_GET['q'];
				$crypt_id = md5($_GET['q']);
				
				$stmt = "SELECT * FROM rs_applications WHERE id = '$app_id' AND application_status='Not Submitted'";
									
				$result = mysqli_query($link, $stmt);
				
				if (mysqli_num_rows($result) > 0) {
					while($row = mysqli_fetch_assoc($result)) {
				
				?>
				
				<!--
				/////////////////
				APPLICATION FORM UPDATE
				////////////////
				-->
		<div class="row no-gutters">
            <div class="col-lg-6 pr-lg-2">
              <div class="card mb-3">
                <div class="card-header">
                  <h5 class="mb-0">Application Details</h5>
                </div>
                <div class="card-body bg-light">
                	<h4 class="mb-4">Application No: <?php echo $row["id"]; ?></h4>
                  <form id="app-form" action="/robasign/event-edit.php?q=<?php echo $app_id; ?>&app_id=<?php echo $crypt_id; ?>" method="post" enctype="multipart/form-data">
                    <div class="form-row">
                      <div class="col-6">
                        <div class="form-group">
                          <label for="event-name">First Name</label>
                          <input class="form-control" id="first-name" name="first-name" value="<?php echo $row["firstname"]; ?>" type="text" placeholder="First Name" required>
                        </div>
                      </div>
					  <div class="col-6">
                        <div class="form-group">
                          <label for="event-name">Last Name</label>
                          <input class="form-control" id="last-name" name="last-name" value="<?php echo $row["lastname"]; ?>" type="text" placeholder="Last Name" required>
                        </div>
                      </div>
					  <div class="col-6">
                        <div class="form-group">
                          <label for="event-name">Mobile</label>
                          <input class="form-control" id="first-name" name="mobile" value="<?php echo $row["mobile"]; ?>" type="text" placeholder="Mobile" required>
                        </div>
                      </div>
					  <div class="col-6">
                        <div class="form-group">
                          <label for="event-name">Email</label>
                          <input class="form-control" id="email" name="email" value="<?php echo $row["email"]; ?>" type="email" placeholder="Email" required>
                        </div>
                      </div>
                      <div class="col-12">
                        <hr class="border-dashed border-bottom-0">
                      </div>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="event-address">Address 1</label>
                          <input class="form-control" id="event-address1" name="address1" value="<?php echo $row["address1"]; ?>" type="text" placeholder="Address 1" required>
                        </div>
                      </div>
					  <div class="col-sm-6">
                        <div class="form-group">
                          <label for="event-address">Address 2</label>
                          <input class="form-control" id="event-address2" name="address2" value="<?php echo $row["address2"]; ?>" type="text" placeholder="Address 2">
                        </div>
                      </div>
                      <div class="col-sm-4">
                        <div class="form-group">
                          <label for="event-city">City</label>
                          <input class="form-control" id="event-city" name="city" value="<?php echo $row["city"]; ?>" type="text" placeholder="City" required>
                        </div>
                      </div>
                      <div class="col-sm-4">
                        <div class="form-group">
                          <label for="event-state">County</label>
                          <input class="form-control" id="county" name="county" value="<?php echo $row["state"]; ?>" type="text" placeholder="County" required>
                        </div>
                      </div>
                      <div class="col-sm-4">
                        <div class="form-group">
                          <label for="event-country">Post Code</label>
                          <input class="form-control" id="event-postcode" name="post-code" value="<?php echo $row["zip"]; ?>" type="text" placeholder="Post Code" required>
                        </div>
                      </div>
                      <div class="col-12">
                        <div class="form-group">
                          <label for="event-description">Description</label>
                          <textarea class="form-control" id="event-description" name="description" rows="6"><?php echo $row["description"]; ?></textarea>
                        </div>
                      </div>
                    </div>
                </div>
              </div>
            </div>
          <div class="col-lg-6 pl-lg-2">
              <!--<div class="sticky-top sticky-sidebar"> -->
                <div class="card mb-3">
                  <div class="card-header">
                    <h5 class="mb-0">Other Info</h5>
					</div>
					<div class="card-body bg-light">
                    <div class="form-group">
                      <label for="event-type">Product Type</label>
                      <select class="custom-select" id="event-type" name="product-type" required>
                        <option value="">Select Product Type</option>
                        <option value="Residential" <?php if($row["product_type"]=="Residential") echo 'selected="selected"'; ?> >Residential</option>
                        <option value="Commercial" <?php if($row["product_type"]=="Commercial") echo 'selected="selected"'; ?> >Commercial</option>
                        <option value="Bridging" <?php if($row["product_type"]=="Bridging") echo 'selected="selected"'; ?> >Bridging</option>
                      </select>
                    </div>
                    </div>
                </div>
				<div class="card mb-3">
                  <div class="card-header">
                    <h5 class="mb-0">Company Info</h5>
					</div>
					<div class="card-body bg-light">
					<div class="form-row">
                      <div class="col-6">
                        <div class="form-group">
                          <label for="event-name">Company Name</label>
                          <input class="form-control" id="companyname" name="companyname" type="text" placeholder="Company Name" value="<?php echo $row["companyname"]?>" required>
                        </div>
                      </div>
					  <div class="col-6">
                        <div class="form-group">
                          <label for="event-name">Post Code</label>
                          <input class="form-control" id="companypostcode" name="companypostcode" type="text" placeholder="Post Code" value="<?php echo $row["companypostcode"]; ?>" required>
                        </div>
                      </div>
					</div>
					</div>
                </div>
                <div class="card mb-3">
                  <div class="card-header">
                    <h5 class="mb-0">Upload Documents</h5>
					</div>
					<div class="card-body bg-light">
                    <div class="row no-gutters">
                    <div class="col-md-6 mb-3">
                        <div class="form-group">
                          <label for="event-country">Bank Statement 1</label>
                          <input class="form-control-file" id="bankStatement1" name="bs1" type="file">
                        </div>
						<?php if ($row["bankstatement1"] != "") {echo '<button class="btn btn-secondary btn-sm m-1" type="button" data-toggle="tooltip" data-html="true" title="&lt;em&gt;'.$row["bankstatement1"].'&lt;/em&gt;">'.add3dots($row["bankstatement1"], ". . .", 18).'</button>';}?>
						
                      </div>
                      <div class="col-md-6 mb-3">
                      	<div class="form-group">
                          <label for="event-country">Payslip 1</label>
                          <input class="form-control-file" id="payslip1" name="ps1" type="file">
                        </div>
						<?php if ($row["payslip1"] != "") {echo '<button class="btn btn-secondary btn-sm m-1" type="button" data-toggle="tooltip" data-html="true" title="&lt;em&gt;'.$row["payslip1"].'&lt;/em&gt;">'.add3dots($row["payslip1"], ". . .", 18).'</button>';}?>
                    </div>
                      <div class="col-md-6 mb-3">
                        <div class="form-group">
                          <label for="event-country">Bank Statement 2</label>
                          <input class="form-control-file" id="bankStatement2" name="bs2" type="file">
                        </div>
						<?php if ($row["bankstatement2"] != "") {echo '<button class="btn btn-secondary btn-sm m-1" type="button" data-toggle="tooltip" data-html="true" title="&lt;em&gt;'.$row["bankstatement2"].'&lt;/em&gt;">'.add3dots($row["bankstatement2"], ". . .", 18).'</button>';}?>
                        </div>
                      <div class="col-md-6 mb-3">
                      	<div class="form-group">
                          <label for="event-country">Payslip 2</label>
                          <input class="form-control-file" id="payslip2" name="ps2" type="file">
                        </div>
						<?php if ($row["payslip2"] != "") {echo '<button class="btn btn-secondary btn-sm m-1" type="button" data-toggle="tooltip" data-html="true" title="&lt;em&gt;'.$row['payslip2'].'&lt;/em&gt;">'.add3dots($row["payslip2"], ". . .", 18).'</button>';}?>
                    </div>
                      <div class="col-md-6 mb-3">
                        <div class="form-group">
                          <label for="event-country">Bank Statement 3</label>
                          <input class="form-control-file" id="bankStatement3" name="bs3" type="file">
                        </div>
						<?php if ($row["bankstatement3"] != "") {echo '<button class="btn btn-secondary btn-sm m-1" type="button" data-toggle="tooltip" data-html="true" title="&lt;em&gt;'.$row['bankstatement3'].'&lt;/em&gt;">'.add3dots($row["bankstatement3"], ". . .", 18).'</button>';}?>
                        </div>
                    <div class="col-md-6 mb-3">
                      	<div class="form-group">
                          <label for="event-country">Payslip 3</label>
                          <input class="form-control-file" id="payslip3" name="ps3" type="file">
                        </div>
						<?php if ($row["payslip3"] != "") {echo '<button class="btn btn-secondary btn-sm m-1" type="button" data-toggle="tooltip" data-html="true" title="&lt;em&gt;'.$row['payslip3'].'&lt;/em&gt;">'.add3dots($row["payslip3"], ". . .", 18).'</button>';}?>
                    </div>
                      </div>
                  </div>
                </div>
              <!--</div> -->
            </div>
			</div>
								<?php
										}?>
									
          <div class="card mt-3">
            <div class="card-body">
              <div class="row justify-content-between align-items-center">
                <div class="col-md">
                  <h5 class="mb-2 mb-md-0">Nice Job! You're almost done</h5>
                </div>
                <div class="col-auto">
				<input type="button" class="btn btn-falcon-danger btn-md mr-2" name="cancel" value="Cancel" onClick="window.location.href='modify';" />
				<button id="save" name="save" class="btn btn-falcon-default btn-md mr-2" type="submit" role="button">Save</button>
                <button class="btn btn-falcon-primary btn-md mr-2" type="submit" name="submit" role="button">Submit</button>
				<!--<button class="btn btn-falcon-danger btn-md" onClick="window.location='modify';" value="cancel" type="submit" name="cancel" role="button">Cancel</button>-->
                </div>
              </div>
            </div>
          </div>
		  </form>
		  <?php
			} else {
										
									}
									
									mysqli_close($link);
									
								?>
          <footer>
            <div class="row no-gutters justify-content-between fs--1 mt-4 mb-3">
            </div>
          </footer>
        </div>
      </div>
    </main>
    <!-- ===============================================-->
    <!--    End of Main Content-->
    <!-- ===============================================-->

    <!-- ===============================================-->
    <!--    JavaScripts-->
    <!-- ===============================================-->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.js"></script>
    <script src="assets/lib/stickyfilljs/stickyfill.min.js"></script>
    <script src="assets/lib/sticky-kit/sticky-kit.min.js"></script>
    <script src="assets/lib/is_js/is.min.js"></script>
    <script src="assets/lib/@fortawesome/all.min.js"></script>
    <script src="assets/lib/select2/select2.min.js"></script>
    <script src="assets/lib/flatpickr/flatpickr.min.js"></script>
    <script src="assets/js/theme.js"></script>

  </body>

</html>