'use strict';

import utils from './Utils';

/*-----------------------------------------------
|   Tabs
-----------------------------------------------*/
utils.$document.ready(() => {
  $('.toast').toast();
});
