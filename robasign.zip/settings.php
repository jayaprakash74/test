<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: /");
    exit;
}
?>
<?php
	// Include config file
	require_once "config.php";
	$user_id = trim($_SESSION['id']);
?>



<!DOCTYPE html>
<html lang="en-US" dir="ltr">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <!-- ===============================================-->
    <!--    Document Title-->
    <!-- ===============================================-->
    <title>Settings | Robasign</title>


    <!-- ===============================================-->
    <!--    Favicons-->
    <!-- ===============================================-->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/favicon-16x16.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicons/favicon.ico">
    <link rel="manifest" href="assets/img/favicons/manifest.json">
    <meta name="msapplication-TileImage" content="assets/img/favicons/mstile-150x150.png">
    <meta name="theme-color" content="#ffffff">


    <!-- ===============================================-->
    <!--    Stylesheets-->
    <!-- ===============================================-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700%7cPoppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="assets/lib/owl.carousel/owl.carousel.css" rel="stylesheet">
    <link href="assets/lib/fancybox/jquery.fancybox.min.css" rel="stylesheet">
    <link href="assets/lib/flatpickr/flatpickr.min.css" rel="stylesheet">
    <link href="assets/css/theme.css" rel="stylesheet">

  </head>


  <body>

    <!-- ===============================================-->
    <!--    Main Content-->
    <!-- ===============================================-->
    <main class="main" id="top">


      <div class="container-fluid">
        <?php include 'menu.php'; ?>
        <div class="content">
          <?php include 'header_bar.php'; ?>
          <!--<div class="row">
            <div class="col-12">
              <div class="card mb-3 btn-reveal-trigger">
                <div class="card-header position-relative min-vh-25 mb-8">
                  <div class="cover-image">
                    <div class="bg-holder rounded-soft rounded-bottom-0" style="background-image:url(assets/img/generic/4.jpg);">
                    </div>
                    <!--/.bg-holder-->

                    <!--<input class="d-none" id="upload-cover-image" type="file">
                    <label class="cover-image-file-input" for="upload-cover-image"><span class="fas fa-camera mr-2"></span><span>Change cover photo</span></label>
                  </div>
                  <div class="avatar avatar-5xl avatar-profile shadow-sm img-thumbnail rounded-circle">
                    <div class="h-100 w-100 rounded-circle overflow-hidden position-relative"> <img src="assets/img/team/2.jpg" width="200" alt="">
                      <input class="d-none" id="profile-image" type="file">
                      <label class="mb-0 overlay-icon d-flex flex-center" for="profile-image"><span class="bg-holder overlay overlay-0"></span><span class="z-index-1 text-white text-center fs--1"><span class="fas fa-camera"></span><span class="d-block">Update</span></span></label>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div> -->
		  <?php
			if (isset($_POST['updatedetails'])) {
	
				// Processing form data when form is submitted
				if($_SERVER["REQUEST_METHOD"] == "POST"){
					$upd = $link->prepare("UPDATE registration SET firstname = ?, lastname = ?, email = ?, phone = ? WHERE id = ?");
					$upd->bind_param("sssss", $firstname, $lastname, $email, $phone, $id);
		
					$firstname 	= $_POST["first-name"];
					$lastname 	= $_POST["last-name"];
					$email 		= $_POST["email"];
					$phone 		= $_POST["phone"];
					$id 		= $_SESSION["id"];
					
					
					if ($upd->execute()) {
						?><div id="successMessages" class="alert alert-success alert-dismissible" role="alert">
								<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
								<div id="messages_content"><?php echo"Profile Updated Successfully"; ?> <?php //echo $last_id; ?></div>
							</div>
					<?php
					} else {
						?>
						<div id="failMessages" class="alert alert-danger alert-dismissible" role="alert">
								<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
								<div id="messages_content"><?php echo"Profile is not updated"; ?></div>
							</div>
					<?php
					}
				}
			}
		  ?>
		  
		  <?php
			if (isset($_POST['update-password'])) {
	
				// Processing form data when form is submitted
				if ($_SERVER["REQUEST_METHOD"] == "POST"){
					
					$newpwd = $_POST["new_password"];
					$oldpwd = $_POST["old_password"];
					
					if ($newpwd == $oldpwd) {
					$vid = $_SESSION["id"];
					$pwd = "SELECT hashed_password FROM registration WHERE id = '$vid'";
									
					$result = mysqli_query($link, $pwd);

					$old_password = md5($_POST["old_password"]);
					
					$result = mysqli_query($link, $pwd);
									
					if (mysqli_num_rows($result) > 0) {
						while($row = mysqli_fetch_assoc($result)) {
							if ($row["hashed_password"] == $old_password) {
								$updpwd = $link->prepare("UPDATE registration SET hashed_password = ? WHERE id = ?");
								$updpwd->bind_param("ss", $new_pwd, $id);
								
								$new_pwd = md5($_POST["new_password"]);
								$id = $_SESSION["id"];

								if ($updpwd->execute()) {
									?>
									<div id="successMessages" class="alert alert-success alert-dismissible" role="alert">
										<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
										<div id="messages_content"><?php echo "Password Updated Successfully"; ?></div>
									</div>
								<?php
								} else {
									?>
									<div id="failMessages" class="alert alert-danger alert-dismissible" role="alert">
										<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
										<div id="messages_content"><?php echo "Password cannot be updated"; ?></div>
									</div>
								<?php
								}
							} else {
								?>
								<div id="failMessages" class="alert alert-danger alert-dismissible" role="alert">
									<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
									<div id="messages_content"><?php echo "Old Password not Matches"; ?></div>
								</div>
							<?php
							}
						}
					} else {
					?>	
						<div id="failMessages" class="alert alert-danger alert-dismissible" role="alert">
									<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
									<div id="messages_content"><?php echo "Old Password not Matches"; ?></div>
								</div>
				<?php		
					}
				} else {
					?>
						<div id="failMessages" class="alert alert-danger alert-dismissible" role="alert">
								<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
								<div id="messages_content"><?php echo"Entered Passwords do not Match"; ?></div>
							</div>
			<?php
				}
				
				}
			}
		  ?>
		  
		  <?php 
			$stmt = "SELECT * FROM registration WHERE id = '$user_id'";
									
			$result = mysqli_query($link, $stmt);
									
			if (mysqli_num_rows($result) > 0) {
				while($row = mysqli_fetch_assoc($result)) {
		  ?>
          <div class="row no-gutters">
            <div class="col-lg-8 pr-lg-2">
              <div class="card mb-3">
                <div class="card-header">
                  <h5 class="mb-0">Profile Settings</h5>
                </div>
                <div class="card-body bg-light">
                  <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" id="update-form">
                    <div class="row">
                      <div class="col-lg-6">
                        <div class="form-group">
                          <label for="first-name">First Name</label>
                          <input class="form-control" id="first-name" name="first-name" type="text" value="<?php echo $row["firstname"]; ?>">
                        </div>
                      </div>
                      <div class="col-lg-6">
                        <div class="form-group">
                          <label for="last-name">Last Name</label>
                          <input class="form-control" id="last-name" name="last-name" type="text" value="<?php echo $row["lastname"]; ?>">
                        </div>
                      </div>
                      <div class="col-lg-6">
                        <div class="form-group">
                          <label for="email1">Email</label>
                          <input class="form-control" id="email1" name="email" type="email" value="<?php echo $row["email"]; ?>">
                        </div>
                      </div>
                      <div class="col-lg-6">
                        <div class="form-group">
                          <label for="phone">Phone</label>
                          <input class="form-control" id="phone" name="phone" type="text" value="<?php echo $row["phone"]; ?>">
                        </div>
                      </div>
                      <div class="col-12">
                        <div class="form-group">
                          <label for="heading">Heading</label>
                          <input class="form-control" id="heading" name="heading" type="text" value="Software Engineer">
                        </div>
                      </div>
                      <div class="col-12">
                        <div class="form-group">
                          <label for="intro">Intro</label>
                          <textarea class="form-control" id="intro" name="intro" cols="30" rows="13">Dedicated, passionate, and accomplished Full Stack Developer with 9+ years of progressive experience working as an Independent Contractor for Google and developing and growing my educational social network that helps others learn programming, web design, game development, networking. I’ve acquired a wide depth of knowledge and expertise in using my technical skills in programming, computer science, software development, and mobile app development to developing solutions to help organizations increase productivity, and accelerate business performance. It’s great that we live in an age where we can share so much with technology but I’m but I’m ready for the next phase of my career, with a healthy balance between the virtual world and a workplace where I help others face-to-face. There’s always something new to learn, especially in IT-related fields. People like working with me because I can explain technology to everyone, from staff to executives who need me to tie together the details and the big picture. I can also implement the technologies that successful projects need.</textarea>
                        </div>
                      </div>
                      <div class="col-12 d-flex justify-content-end">
                        <button class="btn btn-primary" id="updatedetails" name="updatedetails" type="submit">Update</button>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
            <div class="col-lg-4 pl-lg-2">
              <div class="sticky-top sticky-sidebar">
                <div class="card mb-3">
                  <div class="card-header">
                    <h5 class="mb-0">Change Password</h5>
                  </div>
                  <div class="card-body bg-light">
                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post" id="update-password" required>
                      <div class="form-group">
                        <label for="old-password">Old Password</label>
                        <input class="form-control" id="old-password" name="old_password" type="password" required>
                      </div>
                      <div class="form-group">
                        <label for="new-password">New Password</label>
                        <input class="form-control" id="new-password" name="new_password" type="password" required>
                      </div>
                      <div class="form-group">
                        <label for="confirm-password">Confirm Password</label>
                        <input class="form-control" id="confirm-password" name="confirm_password" type="password">
                      </div>
                      <button class="btn btn-primary btn-block" name="update-password" type="submit">Update Password</button>
                    </form>
                  </div>
                </div>
                <div class="card">
                  <div class="card-header">
                    <h5 class="mb-0">Danger Zone</h5>
                  </div>
                  <div class="card-body bg-light">
                    <h5 class="fs-0">Delete this account</h5>
                    <p class="fs--1">Once you delete a account, there is no going back. Please be certain.</p><button class="btn btn-falcon-danger d-block" id="deactivate" type="submit" name="deactivate">Deactivate Account</button>
                  </div>
                </div>
              </div>
            </div>
          </div>
		  <?php
				}
			}
		  ?>
          <footer>
            <div class="row no-gutters justify-content-between fs--1 mt-4 mb-3">
            </div>
          </footer>
        </div>
      </div>
    </main>
    <!-- ===============================================-->
    <!--    End of Main Content-->
    <!-- ===============================================-->




    <!-- ===============================================-->
    <!--    JavaScripts-->
    <!-- ===============================================-->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.js"></script>
    <script src="assets/lib/stickyfilljs/stickyfill.min.js"></script>
    <script src="assets/lib/sticky-kit/sticky-kit.min.js"></script>
    <script src="assets/lib/is_js/is.min.js"></script>
    <script src="assets/lib/@fortawesome/all.min.js"></script>
    <script src="assets/lib/owl.carousel/owl.carousel.js"></script>
    <script src="assets/lib/fancybox/jquery.fancybox.min.js"></script>
    <script src="assets/lib/flatpickr/flatpickr.min.js"></script>
    <script src="assets/js/theme.js"></script>

  </body>

</html>
