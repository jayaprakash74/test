<?php
    // Initialize the session
    session_start();
     
    // Check if the user is logged in, if not then redirect him to login page
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
        header("location: /");
        exit;
    }
	
	// Include config file
	require_once "config.php";
?>

<!DOCTYPE html>
<html lang="en-US" dir="ltr">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- ===============================================-->
        <!--    Document Title-->
        <!-- ===============================================-->
        <title>Manual Verification | Robasign</title>
        <!-- ===============================================-->
        <!--    Favicons-->
        <!-- ===============================================-->
        <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/favicon-16x16.png">
        <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicons/favicon.ico">
        <link rel="manifest" href="assets/img/favicons/manifest.json">
        <meta name="msapplication-TileImage" content="assets/img/favicons/mstile-150x150.png">
        <meta name="theme-color" content="#ffffff">
        <!-- ===============================================-->
        <!--    Stylesheets-->
        <!-- ===============================================-->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700%7cPoppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
        <link href="assets/lib/jqvmap/jqvmap.min.css" rel="stylesheet">
        <link href="assets/lib/datatables-bs4/dataTables.bootstrap4.min.css" rel="stylesheet">
        <link href="assets/lib/datatables.net-responsive-bs4/responsive.bootstrap4.css" rel="stylesheet">
        <link href="assets/css/theme.css" rel="stylesheet">
    </head>
    <body>
        <!-- ===============================================-->
        <!--    Main Content-->
        <!-- ===============================================-->
        <main class="main" id="top">
            <div class="container-fluid">
                <?php include 'menu.php'; ?>
                <div class="content">
                    <?php include 'header_bar.php';?>
                    <div class="card-body p-0">		
					
					
					
<?php 
	$app_id = $_GET['q'];
$details = "SELECT * FROM rs_applications WHERE id = '$app_id' ";

$result = mysqli_query($link, $details);
									
if (mysqli_num_rows($result) > 0) {
	while($row = mysqli_fetch_assoc($result)) {
?>		
	<div class="card mb-3">
            <div class="card-header">
              <div class="row align-items-center">
                <div class="col">
                  <h5 class="mb-0">Details</h5>
                </div>
                <!--<div class="col-auto"><a class="btn btn-falcon-default btn-sm" href="#!"><span class="fas fa-pencil-alt fs--2 mr-1"></span>Update details</a></div>-->
              </div>
            </div>
            <div class="card-body bg-light border-top">
              <div class="row">
                <div class="col-lg col-xxl-5">
                  <h6 class="font-weight-semi-bold ls mb-3 text-uppercase">Application Information</h6>
                  <div class="row">
                    <div class="col-5 col-sm-4">
                      <p class="font-weight-semi-bold mb-1">ID</p>
                    </div>
					<div class="col"><?php echo $row["id"]; ?></div> 
                  </div>
				  <div class="row">
                    <div class="col-5 col-sm-4">
                      <p class="font-weight-semi-bold mb-1">Customer Name</p>
                    </div>
                    <div class="col"><?php echo $row["firstname"]; ?> <?php echo $row["lastname"]; ?></div>
                  </div>
				  <div class="row">
                    <div class="col-5 col-sm-4">
                      <p class="font-weight-semi-bold mb-1">Type of Verification</p>
                    </div>
                    <div class="col"><?php echo $row["product_type"]; ?></div>
                  </div>
				  <div class="row">
                    <div class="col-5 col-sm-4">
                      <p class="font-weight-semi-bold mb-1">Status</p>
                    </div>
                    <div class="col"><?php echo $row["application_status"]; ?></div>
                  </div>
                  <div class="row">
                    <div class="col-5 col-sm-4">
                      <p class="font-weight-semi-bold mb-1">Created</p>
                    </div>
                    <div class="col"><?php echo $row["created"]; ?></div>
                  </div>
                  <div class="row">
                    <div class="col-5 col-sm-4">
                      <p class="font-weight-semi-bold mb-1">Email</p>
                    </div>
                    <div class="col"><a href="mailto:<?php echo $row['email']; ?>"><?php echo $row["email"]; ?></a></div>
                  </div>
                  <div class="row">
                    <div class="col-5 col-sm-4">
                      <p class="font-weight-semi-bold mb-1">Description</p>
                    </div>
                    <div class="col">
                      <p class="font-weight-semi-bold mb-1"><?php echo $row["description"]; ?></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!--<div class="card-footer border-top text-right"><a class="btn btn-falcon-default btn-sm" href="#!"><span class="fas fa-dollar-sign fs--2 mr-1"></span>Refund</a><a class="btn btn-falcon-default btn-sm ml-2" href="#!"><span class="fas fa-check fs--2 mr-1"></span>Save changes</a></div>-->
          </div>
<?php 
}
}
?>

<?php 
if (isset($_POST['update'])) {
	
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
	
	$stmt2 = $link->prepare("INSERT INTO verificationstatus (ApplicationID, DocCode, DocumentStatus, Comments, ModifiedBy) VALUES (?, ?, ?, ?, ?)");
	$stmt2->bind_param("sssss", $app_id2, $doccode2, $docstatus2, $comments2, $modifiedby2);
	
	$app_id2 = $_GET['q'];
	$doccode2 = $_POST['modaldoccode1'];
	$docstatus2 = "Verified Manually";
	$comments2 = $_POST['description'];
	$modifiedby2 = trim($_SESSION["id"]);
	
	if ($stmt2->execute()) {
		echo "Insert Successful";
		
		$stmt3 = $link->prepare("INSERT INTO verificationstatus (ApplicationID, DocCode, DocumentStatus, Comments, ModifiedBy) VALUES (?, ?, ?, ?, ?)");
	$stmt3->bind_param("sssss", $app_id3, $doccode3, $docstatus3, $comments3, $modifiedby3);
	
	$app_id3 = $_GET['q'];
	$doccode3 = $_POST['modaldoccode2'];
	$docstatus3 = "Verified Manually";
	$comments3 = $_POST['description'];
	$modifiedby3 = trim($_SESSION["id"]);
	
	if ($stmt3->execute()) {
		
		$upd = $link->prepare("UPDATE rs_applications SET application_status = ? WHERE id = ?");
		$upd->bind_param("ss", $success, $app_id3);
		
		$success = "Verification Successful";
		$app_id3 = $_GET['q'];
		
		$upd->execute();
	}
		
	} else {
		echo "Not Inserted";
	}
	
	
}
}
?>
				<div class="card mb-3">
				<div class="card-header">
                            <div class="row align-items-center justify-content-between">
                                <div class="col-6 col-sm-auto d-flex align-items-center pr-0">
                                    <h5 class="fs-0 mb-0 text-nowrap py-2 py-xl-0">Applicant Status</h5>
                                </div>
							</div>
					</div>
					<div class="card-body col-xxl-5 p-0">
                        <div class="dashboard-data-table">
                            <table class="table table-sm mb-0 table-dashboard fs--1 data-table border-bottom" data-options='{"responsive":false,"pagingType":"simple","lengthChange":false,"searching":false,"pageLength":8,"columnDefs":[{"targets":[0,6],"orderable":false}],"language":{"info":"_START_ to _END_ Items of _TOTAL_ — <a href=\"#!\" class=\"font-weight-semi-bold\"> view all <span class=\"fas fa-angle-right\" data-fa-transform=\"down-1\"></span> </a>"},"dom":"<&#39;row mx-1&#39;<&#39;col-sm-12 col-md-6&#39;l><&#39;col-sm-12 col-md-6&#39;f>><&#39;table-responsive&#39;tr><&#39;row no-gutters px-1 py-3 align-items-center&#39;<&#39;col pl-3&#39;i><&#39;col-auto pr-3&#39;p>>"}'>
                                <thead class="bg-200 text-900">
                                    <tr>
                                        <th class="sort pr-1 align-middle">Stage of Verification</th>
                                        <th class="sort pr-1 align-middle">Documents Checked</th>
										<th class="no-sort pr-1 align-middle">Status</th>
										<th class="no-sort pr-1 align-middle">Comments</th>
										<th class="no-sort pr-1 align-middle">Update Status</th>
                                    </tr>
                                </thead>
								<tbody>
								
								<?php
									$stmt = "SELECT ID, ApplicationID, GROUP_CONCAT( DocCode ) AS DocCode, GROUP_CONCAT( DocumentStatus ) AS DocumentStatus, GROUP_CONCAT( Comments ) AS Comments FROM verificationstatus WHERE ApplicationID = '$app_id'";
									
									$result = mysqli_query($link, $stmt);
									
									if (mysqli_num_rows($result) > 0) {
										while($row = mysqli_fetch_assoc($result)) {
											?>
											<tr class="btn-reveal-trigger">
												<th class="align-middle fs-0"><?php echo "ID Verification"; ?></th>
												<?php 
													$lineItemArray = explode(',',$row["DocumentStatus"]);
													foreach ($lineItemArray as $line) {
														$verify = $line;
													}
												?>
											<td class="align-middle fs-0"><span class="badge badge rounded-capsule badge-success"><?php echo "Passport"; ?></span>
                                            </td>
											<td class="align-middle fs-0">
												Verification Successful
											</td>
											
											<td class="align-middle fs-0">
												Details Verification Successfully
											</td>
											<td class="align-middle fs-0">
												<span class="badge badge rounded-capsule badge-soft-success">Verified<span class="ml-1 fas fa-check" data-fa-transform="shrink-2"></span></span>
											</td>
											</tr>
											
											<?php
												//echo $row['DocumentStatus'];
												$verifyBtn = explode(',',$row["DocCode"]);
												foreach ($verifyBtn as $verifyb) {
														if ($verifyb == "BS1") {
															$verifyb = "BankStatement 1";
														} elseif ($verifyb == "BS2") {
															$verifyb = "BankStatement 2";
														} elseif ($verifyb == "BS3") {
															$verifyb = "BankStatement 3";
														} elseif ($verifyb == "PS1") {
															$verifyb = "Payslip 1";
														} elseif ($verifyb == "PS2") {
															$verifyb = "Payslip 2";
														} elseif ($verifyb == "PS3") {
															$verifyb = "Payslip 3";
														}
														/*echo '<button class="btn btn-outline-info mr-1 mb-1" data-id="'. $row["ID"] .'" onclick = "openPdf()" type="button" role="button">'. $verifyb .'</button>';*/
												}
											?>
											
											<?php
												$dcode = explode(',',$row["DocCode"]);
												//echo $row['DocCode'];
												if ($dcode[0] == "PS1") {
													$code = "PS1";
												} elseif ($dcode[1] == "BS1") {
													$code = "BS1";
												} elseif ($dcode[2] == "PS2") {
													$code = "PS2";
												} elseif ($dcode[3] == "BS") {
													$code = "BS2";
												} elseif ($dcode[4] == "PS3") {
													$code = "PS3";
												} elseif ($dcode[5] == "BS3") {
													$code = "BS3";
												} 
												//echo $row["Comments"];
											?>
											
											<tr class="btn-reveal-trigger">
											<th class="align-middle fs-0" rowspan="4">
												Salary Verification
											</th>
											</tr>
											
											<tr>
											<td class="align-middle">
													<button class="badge badge rounded-capsule badge-success" onclick = "openbank1()" type="button" role="button"><?php echo "BankStatement 1"; ?></button>
													<button class="badge badge rounded-capsule badge-success" onclick = "openslip1()" type="button" role="button"><?php echo "Salary slip 1"; ?></button>
											</td>
											
											<td class="align-middle fs-0">
													<?php 
														$status1 = explode(',',$row["DocumentStatus"]);
														
														if (in_array("Verified Manually", $status1) && $dcode[6] == "PS1") {
															 echo "Verified Manually";
														 } else {
														 if ($status1[0] && $status1[1] == "Verification Failed") {
															echo $status1[0];
														} elseif ($status1[0] && $status1[1] == "Verification Successful") {
															echo $status1[0];
														}
														 }
													?>
											</td>
											
											<td class="align-middle fs-0">
											<?php
											
											
												$comm = explode(',',$row["Comments"]);
												
												if (in_array("Verified Manually", $status1) && $dcode[6] == "PS1") {
													echo $comm[6];
												} else {
												if ($comm[0] != "") {
													echo $comm[0];
												} elseif ($comm[1] != "") {
													echo $comm[1];
												}
												}
											?>
											</td>
											
											<td class="align-middle fs-0">
													<?php 
														$status1 = explode(',',$row["DocumentStatus"]);
														
														if (in_array("Verified Manually", $status1) && $dcode[6] == "PS1") {
															echo '<span class="badge badge rounded-capsule badge-soft-success">'.$status1[6].'<span class="ml-1 fas fa-check" data-fa-transform="shrink-2"></span></span>';
														} else {
														 if ($status1[0] && $status1[1] == "Verification Failed") {
															echo '<button class="btn btn-info mr-1 mb-1" data-id="'. $row["ID"] .'" type="button" data-toggle="modal" data-target="#update1" role="button">Update Status</button>';
														} elseif ($status1[0] && $status1[1] == "Verification Successful") {
															echo '<span class="badge badge rounded-capsule badge-soft-success">'.$status1[0].'<span class="ml-1 fas fa-check" data-fa-transform="shrink-2"></span></span>';
														}
														}
													?>
											</td>

<div class="modal fade" id="update1" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Confirm Status Update</h5><button class="close" type="button" data-dismiss="modal" aria-label="Close"><span class="font-weight-light" aria-hidden="true">&times;</span></button>
      </div>
	  <form action="" method="post">
	  <input id="app_id" name="app_id" value="<?php echo $app_id;?>" hidden />
	  <input id="modaldoccode1" name="modaldoccode1" value="PS1" hidden />
	  <input id="modaldoccode2" name="modaldoccode2" value="BS1" hidden />
	  
      <div class="modal-body">
        <textarea class="form-control" id="description" name="description" rows="6" required ></textarea>
      </div>
      <div class="modal-footer"><button class="btn btn-danger btn-sm" type="button" data-dismiss="modal">Cancel</button><button class="btn btn-success btn-sm" name="update" type="submit">Update</button></div>
	  </form>
    </div>
  </div>
</div>											
											</tr>
											
											<tr>
											<td class="align-middle">
													<button class="badge badge rounded-capsule badge-success" onclick = "openbank2()" type="button" role="button"><?php echo "BankStatement 2"; ?></button>
													<button class="badge badge rounded-capsule badge-success" onclick = "openslip2()" type="button" role="button"><?php echo "Salary slip 2"; ?></button>
											</td>
											
											<td class="align-middle fs-0">
													<?php 
														$status2 = explode(',',$row["DocumentStatus"]);
														
														 if (in_array("Verified Manually", $status2) && $dcode[6] == "PS2") {
															 echo "Verified Manually";
														 } else {
														 if ($status2[2] && $status2[3] == "Verification Failed") {
															echo $status2[2];
														} elseif ($status2[2] && $status2[3] == "Verification Successful") {
															echo $status2[2];
														}
														 }
													?>
											</td>
											
											<td class="align-middle fs-0">
											<?php
												$comm2 = explode(',',$row["Comments"]);
												
												if (in_array("Verified Manually", $status1) && $dcode[6] == "PS2") {
													echo $comm[6];
												} else {
												if ($comm2[2] != "") {
													echo $comm2[2];
												} elseif ($comm2[3] != "") {
													echo $comm2[3];
												}
												}
											?>
											</td>
											
											<td class="align-middle fs-0">
													<?php 
														$status2 = explode(',',$row["DocumentStatus"]);
														
														if (in_array("Verified Manually", $status2) && $dcode[6] == "PS2") {
															 echo '<span class="badge badge rounded-capsule badge-soft-success">Verified Manually<span class="ml-1 fas fa-check" data-fa-transform="shrink-2"></span></span>';
														 } else {
														 if ($status2[2] && $status2[3] == "Verification Failed") {
															echo '<button class="btn btn-info mr-1 mb-1" data-id="'. $row["ID"] .'" type="button" data-toggle="modal" data-target="#update2" role="button">Update Status</button>';
														} elseif ($status2[2] && $status2[3] == "Verification Successful") {
															echo '<span class="badge badge rounded-capsule badge-soft-success">'.$status2[2].'<span class="ml-1 fas fa-check" data-fa-transform="shrink-2"></span></span>';
														}
														 }
													?>
											</td>
<div class="modal fade" id="update2" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Confirm Status Update</h5><button class="close" type="button" data-dismiss="modal" aria-label="Close"><span class="font-weight-light" aria-hidden="true">&times;</span></button>
      </div>
	  <form action="" method="post">
	  <input id="app_id" name="app_id" value="<?php echo $app_id;?>" hidden />
	  <input id="modaldoccode1" name="modaldoccode1" value="PS2" hidden />
	  <input id="modaldoccode2" name="modaldoccode2" value="BS2" hidden />
	  
      <div class="modal-body">
        <textarea class="form-control" id="description" name="description" rows="6" required></textarea>
      </div>
      <div class="modal-footer"><button class="btn btn-danger btn-sm" type="button" data-dismiss="modal">Cancel</button><button class="btn btn-success btn-sm" name="update" type="submit">Update</button></div>
	  </form>
    </div>
  </div>
</div>
											</tr>
											
											<tr>
											<td class="align-middle">
													<button class="badge badge rounded-capsule badge-success" onclick = "openbank3()" type="button" role="button"><?php echo "BankStatement 3"; ?></button>
													<button class="badge badge rounded-capsule badge-success" onclick = "openslip3()" type="button" role="button"><?php echo "Salary slip 3"; ?></button>
											</td>
											
											<td class="align-middle fs-0">
													<?php 
														$status3 = explode(',',$row["DocumentStatus"]);
														
														if (in_array("Verified Manually", $status2) && $dcode[6] == "PS3") {
															 echo "Verified Manually";
														 } else {
														 if ($status3[4] && $status3[5] == "Verification Failed") {
															echo $status3[4];
														} elseif ($status3[4] && $status3[5] == "Verification Successful") {
															echo $status3[4];
														}
														 }
													?>
											</td>
											
											<td class="align-middle fs-0">
											<?php
												$comm3 = explode(',',$row["Comments"]);
												
												if (in_array("Verified Manually", $status1) && $dcode[6] == "PS3") {
													echo $comm[6];
												} else {
												if ($comm3[4] != "") {
													echo $comm3[4];
												} elseif ($comm3[5] != "") {
													echo $comm3[5];
												}
												}
											?>
											</td>
											
											<td class="align-middle fs-0">
													<?php 
														$status3 = explode(',',$row["DocumentStatus"]);
														
														if (in_array("Verified Manually", $status2) && $dcode[6] == "PS3") {
															 echo '<span class="badge badge rounded-capsule badge-soft-success">Verified Manually<span class="ml-1 fas fa-check" data-fa-transform="shrink-2"></span></span>';
														 } else {
														 if ($status3[4] && $status3[5] == "Verification Failed") {
															echo '<button class="btn btn-info mr-1 mb-1" data-id="'. $row["ID"] .'" type="button" data-toggle="modal" data-target="#update3" role="button">Update Status</button>';
														} elseif ($status3[4] && $status3[5] == "Verification Successful") {
															echo '<span class="badge badge rounded-capsule badge-soft-success">'.$status3[4].'<span class="ml-1 fas fa-check" data-fa-transform="shrink-2"></span></span>';
														}
														 }
													?>
											</td>
<div class="modal fade" id="update3" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Confirm Status Update</h5><button class="close" type="button" data-dismiss="modal" aria-label="Close"><span class="font-weight-light" aria-hidden="true">&times;</span></button>
      </div>
	  <form action="" method="post">
	  <input id="app_id" name="app_id" value="<?php echo $app_id;?>" hidden />
	  <input id="modaldoccode1" name="modaldoccode1" value="PS3" hidden />
	  <input id="modaldoccode2" name="modaldoccode2" value="BS3" hidden />
	  
      <div class="modal-body">
        <textarea class="form-control" id="description" name="description" rows="6" required></textarea>
      </div>
      <div class="modal-footer"><button class="btn btn-danger btn-sm" type="button" data-dismiss="modal">Cancel</button><button class="btn btn-success btn-sm" name="update" type="submit">Update</button></div>
	  </form>
    </div>
  </div>
</div>											
											</tr>
											
											<tr class="btn-reveal-trigger">
											<th class="align-middle fs-0">
													Address Verification
											</th>
											<td class="align-middle fs-0">
													Screenshot of Google Maps
											</td>
											<td class="align-middle fs-0">
													Verification Successful
											</td>
											<td class="align-middle fs-0">
													Address Could be Successfully Verified
											</td>
											<td class="align-middle fs-0">
													
											</td>
											</tr>

											<?php
										}
									} else { ?>
										<a href="event-create">
										<button class="btn btn-primary mr-1 mb-1" type="button"><span class="fas fa-plus mr-1" data-fa-transform="shrink-3"></span>Create Application</button>
										</a>
									<?php
									}
									
									mysqli_close($link);
									
								?>
								<?php 
								$attention = "Needs Attention Applications";
								$successfile = "Completed Applications";
								if ($status2[0] == "Verification Successful" && $status2[2] == "Verification Successful" && $status2[4] == "Verification Successful") {
									$files = glob("Main Folder/$successfile/$app_id/*.{pdf}", GLOB_BRACE);
									$file = $files;
									$bs1 = $file[0];
									$bs2 = $file[1];
									$bs3 = $file[2];
									$ps1 = $file[3];
									$ps2 = $file[4];
									$ps3 = $file[5];
									
									//echo $status2[0] , $status2[2] , $status2[4];
									
								} elseif ($status2[2] || $status2[0] || $status2[4] == "Verification Failed" || $status2[6] || $status2[7] == "Verified Manually") {
									$files = glob("Main Folder/$attention/$app_id/*.{pdf}", GLOB_BRACE);
									$file = $files;
									$bs1 = $file[0];
									$bs2 = $file[1];
									$bs3 = $file[2];
									$ps1 = $file[3];
									$ps2 = $file[4];
									$ps3 = $file[5];
								} else {
									echo 'No Files Found for this Application';
								}
								?>
                                </tbody>
                            </table>
								<button class="btn btn-danger mr-1 mt-1 ml-1 mb-1" onclick="closeFrame()" style="display:none" type="button" id="closeBtn" role="button">Close</button>
								<iframe id="myFrame" style="display:none" width="100%" height="500"></iframe>
								<div class="mb-10"></div>
                        </div>
						</div>
						</div>
                    </div>
                </div>
            </div>
        </main>
        <!-- ===============================================-->
        <!--    End of Main Content-->
        <!-- ===============================================-->
		
<script type="text/javascript">
function openbank1() {
	var omyFrame = document.getElementById("myFrame");
	var closeBtn = document.getElementById("closeBtn");
	omyFrame.style.display="block";
	closeBtn.style.display="block";
	omyFrame.src = "<?php if (preg_match("/PS1/", $code)) { echo $bs1; } elseif (preg_match("/PS2/", $code)) { echo $bs2; } elseif (preg_match("/PS3/", $code)) { echo $bs3; } else { echo 'No File Found'; } ?>";
}

function openslip1() {
	var omyFrame = document.getElementById("myFrame");
	var closeBtn = document.getElementById("closeBtn");
	omyFrame.style.display="block";
	closeBtn.style.display="block";
	omyFrame.src = "<?php if (preg_match("/PS1/", $code)) { echo $ps1; } elseif (preg_match("/PS2/", $code)) { echo $ps2; } elseif (preg_match("/PS3/", $code)) { echo $ps3; } ?>";
}

function openbank2() {
	var omyFrame = document.getElementById("myFrame");
	var closeBtn = document.getElementById("closeBtn");
	omyFrame.style.display="block";
	closeBtn.style.display="block";
	omyFrame.src = "<?php if (preg_match("/PS1/", $code)) { echo $bs2; } elseif (preg_match("/PS3/", $code)) { echo $bs3; } ?>";
}

function openslip2() {
	var omyFrame = document.getElementById("myFrame");
	var closeBtn = document.getElementById("closeBtn");
	omyFrame.style.display="block";
	closeBtn.style.display="block";
	omyFrame.src = "<?php if (preg_match("/PS1/", $code)) { echo $ps2; } elseif (preg_match("/PS3/", $code)) { echo $ps3; } ?>";
}

function openbank3() {
	var omyFrame = document.getElementById("myFrame");
	var closeBtn = document.getElementById("closeBtn");
	omyFrame.style.display="block";
	closeBtn.style.display="block";
	omyFrame.src = "<?php if (preg_match("/PS1/", $code)) { echo $bs3; } elseif (preg_match("/PS3/", $code)) { echo $ps3; } ?>";
}

function openslip3() {
	var omyFrame = document.getElementById("myFrame");
	var closeBtn = document.getElementById("closeBtn");
	omyFrame.style.display="block";
	closeBtn.style.display="block";
	omyFrame.src = "<?php if (preg_match("/PS1/", $code)) { echo $ps3; } elseif (preg_match("/PS2/", $code)) { echo $ps2; } elseif (preg_match("/PS3/", $code)) { echo $ps3; } ?>";
}

function closeFrame() {
	var omyFrame = document.getElementById("myFrame");
	var closeBtn = document.getElementById("closeBtn");
	omyFrame.style.display="none";
	closeBtn.style.display="none";
	omyFrame.src = "";
}
</script>

        <!-- ===============================================-->
        <!--    JavaScripts-->
        <!-- ===============================================-->
        <script src="https://canvasjs.com/assets/script/jquery-1.11.1.min.js"></script>
        <script src="https://canvasjs.com/assets/script/jquery.canvasjs.min.js"></script>
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.js"></script>
        <script src="assets/lib/stickyfilljs/stickyfill.min.js"></script>
        <script src="assets/lib/sticky-kit/sticky-kit.min.js"></script>
        <script src="assets/lib/is_js/is.min.js"></script>
        <script src="assets/lib/@fortawesome/all.min.js"></script>
        <script src="assets/lib/chart.js/Chart.min.js"></script>
        <script src="assets/lib/jqvmap/jquery.vmap.js"></script>
        <script src="assets/lib/jqvmap/maps/jquery.vmap.world.js" charset="utf-8"></script>
        <script src="assets/lib/jqvmap/maps/jquery.vmap.usa.js" charset="utf-8"></script>
        <script src="assets/lib/datatables/js/jquery.dataTables.min.js"></script>
        <script src="assets/lib/datatables-bs4/dataTables.bootstrap4.min.js"></script>
        <script src="assets/lib/datatables.net-responsive/dataTables.responsive.js"></script>
        <script src="assets/lib/datatables.net-responsive-bs4/responsive.bootstrap4.js"></script>
        <script src="assets/lib/chart.js/Chart.min.js"></script>
        <script src="assets/js/theme.js"></script>
		
		<script>/*
		$(document).on("click", "#verifySuccess", function() { 
		var id = <?php echo $app_id; ?>;
		$.ajax({
			url: "statusUpdate.php",
			type: "POST",
			cache: false,
			//contentType: 'application/json',
			data:{
				id: id,
				status: "success"
			},
			success: function(dataResult){
				var dataResult = JSON.parse(dataResult);
				alert(dataResult);
				if(dataResult.statusCode==200){
					$('#successMessages').show();
					alert(dataResult);					
				}
			}
		});
	});*/
		</script>
		
    </body>
</html>