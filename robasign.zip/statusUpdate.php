<?php
	include 'config.php';

	$id = $_POST['id'];
	$success = $_POST['success'];
	$result = "Verification Successful";
	$modified = "Manually"

	$sql = "UPDATE verificationstatus SET DocumentStatus = '$result', ModifiedBy = '$modified' WHERE ApplicationID = '$id'";
	
	if (mysqli_query($link, $sql)) {
		echo json_encode(array('statusCode'=>200));
	} 
	else {
		echo json_encode(array('statusCode'=>201));
	}
	mysqli_close($link);
?>