<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: /");
    exit;
}
?>

<?php
	// Include config file
	require_once "config.php";
	$user_id = trim($_SESSION['id']);
?>

<!DOCTYPE html>
<html lang="en-US" dir="ltr">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- ===============================================-->
        <!--    Document Title-->
        <!-- ===============================================-->
        <title>Dashboard | Robasign</title>
        <!-- ===============================================-->
        <!--    Favicons-->
        <!-- ===============================================-->
        <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/favicon-16x16.png">
        <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicons/favicon.ico">
        <link rel="manifest" href="assets/img/favicons/manifest.json">
        <meta name="msapplication-TileImage" content="assets/img/favicons/mstile-150x150.png">
        <meta name="theme-color" content="#ffffff">
        <!-- ===============================================-->
        <!--    Stylesheets-->
        <!-- ===============================================-->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700%7cPoppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
        <link href="assets/lib/jqvmap/jqvmap.min.css" rel="stylesheet">
        <link href="assets/lib/datatables-bs4/dataTables.bootstrap4.min.css" rel="stylesheet">
        <link href="assets/lib/datatables.net-responsive-bs4/responsive.bootstrap4.css" rel="stylesheet">
        <link href="assets/css/theme.css" rel="stylesheet">
        <style>
            #chartdiv {
            width: 100%;
            height: 533px;
            }
        </style>
        <!-- Resources -->
        <script src="https://www.amcharts.com/lib/4/core.js"></script>
        <script src="https://www.amcharts.com/lib/4/charts.js"></script>
        <script src="https://www.amcharts.com/lib/4/themes/frozen.js"></script>
        <script src="https://www.amcharts.com/lib/4/themes/animated.js"></script>
        <!-- Chart code -->
        <script>
            am4core.ready(function() {
            
            // Set theme
            am4core.useTheme(am4themes_animated);
            
            // Create chart instance
            var chart = am4core.create("chartdiv", am4charts.PieChart3D);
            
            // Let's cut a hole in our Pie chart the size of 0% the radius
            chart.innerRadius = am4core.percent(0);
            
            // Add data
            chart.data = [{
              "country": "Not Submitted",
              "litres": <?php							
								$stmt = "SELECT count(*) as total from rs_applications WHERE rs_users_id = '$user_id' AND application_status = 'Not Submitted'";
								
								$result = mysqli_query($link, $stmt);
								
								while($row = mysqli_fetch_assoc($result)) {
									echo $row["total"];
								}
								?>
            }, {
              "country": "In Progress",
              "litres": <?php							
								$stmt = "SELECT count(*) as total from rs_applications WHERE rs_users_id = '$user_id' AND application_status = 'InProgress'";
								
								$result = mysqli_query($link, $stmt);
								
								while($row = mysqli_fetch_assoc($result)) {
									echo $row["total"];
								}
								?>
            }, {
              "country": "Verification Failed",
              "litres": <?php							
								$stmt = "SELECT count(*) as total from rs_applications WHERE rs_users_id = '$user_id' AND application_status = 'Verification Failed'";
								
								$result = mysqli_query($link, $stmt);
								
								while($row = mysqli_fetch_assoc($result)) {
									echo $row["total"];
								}
								?>
            }, {
              "country": "Verification Successful",
              "litres": <?php							
								$stmt = "SELECT count(*) as total from rs_applications WHERE rs_users_id = '$user_id' AND application_status = 'Verification Successful'";
								
								$result = mysqli_query($link, $stmt);
								
								while($row = mysqli_fetch_assoc($result)) {
									echo $row["total"];
								}
								?>
            }];
            
            // Add and configure Series
            var pieSeries = chart.series.push(new am4charts.PieSeries3D());
            pieSeries.dataFields.value = "litres";
            pieSeries.dataFields.category = "country";
            pieSeries.slices.template.stroke = am4core.color("#fff");
            pieSeries.slices.template.strokeWidth = 2;
            pieSeries.slices.template.strokeOpacity = 1;
            
            // Disabling labels and ticks on inner circle
            pieSeries.labels.template.disabled = true;
            pieSeries.ticks.template.disabled = true;
            
            // Disable sliding out of slices
            pieSeries.slices.template.states.getKey("hover").properties.shiftRadius = 0;
            pieSeries.slices.template.states.getKey("hover").properties.scale = 1.1;
            
            // Add a legend
            chart.legend = new am4charts.Legend();
            chart.legend.position = "left";
            
            }); // end am4core.ready()
        </script>
    </head>
	
    <body>
        <!-- ===============================================-->
        <!--    Main Content-->
        <!-- ===============================================-->
        <main class="main" id="top">
            <div class="container-fluid">
                <?php include 'menu.php'; ?>
                <div class="content">
                    <?php include 'header_bar.php';?>
                    <div class="card-deck">
                        <div class="card mb-3 overflow-hidden" style="min-width: 12rem">
                            <div class="bg-holder bg-card" style="background-image:url(assets/img/illustrations/corner-1.png);">
                            </div>
                            <!--/.bg-holder-->
                            <div class="card-body position-relative">
                                <h6>
                                    Total Applications<!--<span class="badge badge-soft-warning rounded-capsule ml-2">-0.23%</span>-->
                                </h6>
                                <div class="display-4 fs-4 mb-2 font-weight-normal text-sans-serif text-warning" data-countupp='{"count":125,"format":"alphanumeric"}'>
								<?php							
								$stmt = "SELECT count(*) as total from rs_applications WHERE rs_users_id = '$user_id'";
								
								$result = mysqli_query($link, $stmt);
								
								while($row = mysqli_fetch_assoc($result)) {
									echo $row["total"];
								}
								?>
								</div>
                                <a class="font-weight-semi-bold fs--1 text-nowrap" href="#!">See all<span class="fas fa-angle-right ml-1" data-fa-transform="down-1"></span></a>
                            </div>
                        </div>
                        <div class="card mb-3 overflow-hidden" style="min-width: 12rem">
                            <div class="bg-holder bg-card" style="background-image:url(assets/img/illustrations/corner-2.png);">
                            </div>
                            <!--/.bg-holder-->
                            <div class="card-body position-relative">
                                <h6>
                                    In Progress<!--<span class="badge badge-soft-info rounded-capsule ml-2">0.0%</span>-->
                                </h6>
                                <div class="display-4 fs-4 mb-2 font-weight-normal text-sans-serif text-info" data-countupp='{"count":73,"format":"alphanumeric"}'>
								<?php							
								$stmt = "SELECT count(*) as total from rs_applications WHERE rs_users_id = '$user_id' AND application_status='InProgress'";
								
								$result = mysqli_query($link, $stmt);
								
								while($row = mysqli_fetch_assoc($result)) {
									echo $row["total"];
								}
								?>
								</div>
                                <a class="font-weight-semi-bold fs--1 text-nowrap" href="#!">All Progress<span class="fas fa-angle-right ml-1" data-fa-transform="down-1"></span></a>
                            </div>
                        </div>
                        <div class="card mb-3 overflow-hidden" style="min-width: 12rem">
                            <div class="bg-holder bg-card" style="background-image:url(assets/img/illustrations/corner-3.png);">
                            </div>
                            <!--/.bg-holder-->
                            <div class="card-body position-relative">
                                <h6>
                                    Completed<!--<span class="badge badge-soft-success rounded-capsule ml-2">9.54%</span>-->
                                </h6>
                                <div class="display-4 fs-4 mb-2 font-weight-normal text-sans-serif" data-countupp='{"count":52,"format":"alphanumeric"}'>
								
								<?php							
								$stmt = "SELECT count(*) as total from rs_applications WHERE rs_users_id = '$user_id' AND application_status='Verification Successful'";
								
								$result = mysqli_query($link, $stmt);
								
								while($row = mysqli_fetch_assoc($result)) {
									echo $row["total"];
								}
								?>
								
								</div>
                                <a class="font-weight-semi-bold fs--1 text-nowrap" href="#!">Statistics<span class="fas fa-angle-right ml-1" data-fa-transform="down-1"></span></a>
                            </div>
                        </div>
                    </div>
                    <div class="card mb-3">
                        <div class="card-header">
                            <div class="row align-items-center justify-content-between">
                                <div class="col-6 col-sm-auto d-flex align-items-center pr-0">
                                    <h5 class="fs-0 mb-0 text-nowrap py-2 py-xl-0">Applicant Status</h5>
                                </div>
                                <div class="col-6 col-sm-auto ml-auto text-right pl-0">
                                    <div class="d-none" id="purchases-actions">
                                        <div class="input-group input-group-sm">
                                            <select class="custom-select cus" aria-label="Bulk actions">
                                                <option selected="">Bulk actions</option>
                                                <option value="Delete">Delete</option>
                                                <option value="Archive">Archive</option>
                                            </select>
                                            <button class="btn btn-falcon-default btn-sm ml-2" type="button">Apply</button>
                                        </div>
                                    </div>
                                    <div id="dashboard-actions">
                                        <a href="event-create"><button class="btn btn-falcon-default btn-sm" type="button"><span class="fas fa-plus" data-fa-transform="shrink-3 down-2"></span><span class="d-none d-sm-inline-block ml-1">New</span></button></a>
                                        <button class="btn btn-falcon-default btn-sm mx-2" type="button"><span class="fas fa-filter" data-fa-transform="shrink-3 down-2"></span><span class="d-none d-sm-inline-block ml-1">Filter</span></button>
                                        <button class="btn btn-falcon-default btn-sm" type="button"><span class="fas fa-external-link-alt" data-fa-transform="shrink-3 down-2"></span><span class="d-none d-sm-inline-block ml-1">Export</span></button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <div class="dashboard-data-table">
                                <table id="purchaseTable" class="table table-sm mb-0 table-dashboard fs--1 data-table border-bottom" data-options='{"responsive":false,"pagingType":"simple","lengthChange":false,"searching":true,"pageLength":10,"columnDefs":[{"targets":[0,6],"orderable":false}],"language":{"info":"_START_ to _END_ Items of _TOTAL_ — <a href=\"#!\" class=\"font-weight-semi-bold\"> view all <span class=\"fas fa-angle-right\" data-fa-transform=\"down-1\"></span> </a>"},"dom":"<&#39;row mx-1&#39;<&#39;col-sm-12 col-md-6&#39;l><&#39;col-sm-12 col-md-6&#39;f>><&#39;table-responsive&#39;tr><&#39;row no-gutters px-1 py-3 align-items-center&#39;<&#39;col pl-3&#39;i><&#39;col-auto pr-3&#39;p>>"}'>
                                    <thead class="bg-200 text-900">
                                        <tr>
                                            <th class="no-sort pr-1 align-middle">
                                                <div class="custom-control custom-checkbox ml-3">
                                                    <input class="custom-control-input checkbox-bulk-select" id="checkbox-bulk-purchases-select" type="checkbox" data-checkbox-body="#purchases" data-checkbox-actions="#purchases-actions" data-checkbox-replaced-element="#dashboard-actions" />
                                                    <label class="custom-control-label" for="checkbox-bulk-purchases-select"></label>
                                                </div>
                                            </th>
                                            <th class="sort pr-1 align-middle">Application ID</th>
                                            <th class="sort pr-1 align-middle">Customer Name</th>
                                            <th class="sort pr-1 align-middle">Email</th>
                                            <th class="sort pr-1 align-middle">Type of Verification</th>
                                            <th class="sort pr-1 align-middle text-center">Status of Application</th>
                                            <th class="sort pr-1 align-middle text-right">Stage of Verification</th>
                                            <th class="no-sort pr-1 align-middle"></th>
                                        </tr>
                                    </thead>
                                    <tbody id="purchases">
                                        
									<?php
									
									$user_id = trim($_SESSION['id']);
									
									$stmt = "SELECT * FROM rs_applications WHERE rs_users_id = '$user_id' ORDER BY id DESC";
									
									$result = mysqli_query($link, $stmt);
									
									if (mysqli_num_rows($result) > 0) {
										while($row = mysqli_fetch_assoc($result)) {
											?>
											<tr class="btn-reveal-trigger">
												<td class="align-middle">
												<div class="custom-control custom-checkbox ml-3">
													<input class="custom-control-input checkbox-bulk-select-target" type="checkbox" id="checkbox-3" />
													<label class="custom-control-label" for="checkbox-3"></label>
												</div>
											</td>
											<td class="align-middle"><?php echo $row["id"]; ?></td>
                                        <th class="align-middle">
										
										<?php 
											if ($row["application_status"] == "Not Submitted") {
												echo '<a href="event-edit?q='.$row["id"].'&app_id='.md5($row["id"]).'">'.$row["firstname"].' '.$row["lastname"].'</a>'; 
											} elseif ($row["application_status"] == "Verification Failed") {
												echo '<a href="error?q='.$row["id"].'&app_id='.md5($row["id"]).'">'.$row["firstname"].' '.$row["lastname"].'</a>';
											} elseif ($row["application_status"] == "Verification Successful" || $row["application_status"] == "Verified Manually") {
												echo '<a href="error?q='.$row["id"].'&app_id='.md5($row["id"]).'">'.$row["firstname"].' '.$row["lastname"].'</a>';
											} elseif ($row["application_status"] == "InProgress") {
												echo $row["firstname"].' '.$row["lastname"];
											}
										?>
										
										</th>
                                        <td class="align-middle"><?php echo $row["email"]; ?></td>
                                        <td class="align-middle"><?php echo $row["product_type"]; ?></td>
										<?php 
											if ($row["application_status"] == "Not Submitted") {
										?>
											<td class="align-middle text-center fs-0"><span class="badge badge rounded-capsule badge-soft-secondary"><?php echo $row["application_status"]?><span class="ml-1 fas fa-stop" data-fa-transform="shrink-2"></span></span>
											</td>
										<?php 
											} elseif ($row["application_status"] == "InProgress") {
										?>		
											<td class="align-middle text-center fs-0"><span class="badge badge rounded-capsule badge-warning"><?php echo $row["application_status"]?><span class="ml-1 fas fa-spinner" data-fa-transform="shrink-2"></span></span>
											</td>
										<?php		
											} elseif ($row["application_status"] == "Verification Successful") {
										?>
											<td class="align-middle text-center fs-0"><span class="badge badge rounded-capsule badge-soft-success"><?php echo $row["application_status"]?><span class="ml-1 fas fa-check" data-fa-transform="shrink-2"></span></span>
                                            </td>
										<?php 
											} elseif ($row["application_status"] == "Verification Failed") {
										?>
											<td class="align-middle text-center fs-0"><a href="error?q=<?php echo $row["id"]; ?>&app_id=<?php echo md5($row["id"]); ?>&key=<?php echo $row["id"]; ?>"><span class="badge badge rounded-capsule badge-danger"><?php echo $row["application_status"]?><span class="ml-1 fas fa-exclamation-triangle" data-fa-transform="shrink-2"></span></span></a>
                                            </td>
										<?php 
											} 
										?>
                                        <td class="align-middle text-right">0/6</td>
                                        <td class="align-middle white-space-nowrap">
                                            <div class="dropdown text-sans-serif">
                                                <button class="btn btn-link text-600 btn-sm dropdown-toggle btn-reveal mr-3" type="button" id="dropdown3" data-toggle="dropdown" data-boundary="viewport" aria-haspopup="true" aria-expanded="false"><span class="fas fa-ellipsis-h fs--1"></span></button>
                                                <div class="dropdown-menu dropdown-menu-right border py-0" aria-labelledby="dropdown3">
                                                    <div class="bg-white py-2">
                                                        <?php if ($row["application_status"] == "Not Submitted") {?><a class="dropdown-item" href="event-edit?q=<?php echo $row["id"]; ?>&app_id=<?php echo md5($row['id']); ?>">Edit</a><?php }?><a class="dropdown-item" href="#!">View</a><a class="dropdown-item" href="#!">Refund</a>
                                                        <div class="dropdown-divider"></div>
                                                        <a class="dropdown-item text-warning" href="#!">Archive</a><a class="dropdown-item text-danger" href="#!">Delete</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
											
											<?php
										}
									} else {?>
										<!--<a href="event-create"><button class="btn btn-primary mr-1 mb-1" type="button">
											<span class="fas fa-plus mr-1" data-fa-transform="shrink-3"></span>Create Application
											</button>
										</a>-->
									<?php
									}
									
									
									
								?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="row no-gutters">
                        <div class="col-lg-4 pr-lg-2">
                            <div class="card h-100 bg-gradient">
                                <center>
                                    <div class="card-header bg-transparent">
                                        <h5 class="text-white">Total Applications</h5>
                                        <div class="real-time-user display-1 font-weight-normal fs-4 text-white" data-countup='{"count":
										
										<?php							
								$stmt = "SELECT count(*) as total from rs_applications WHERE rs_users_id = '$user_id'";
								
								$result = mysqli_query($link, $stmt);
								
								while($row = mysqli_fetch_assoc($result)) {
									echo $row["total"];
								}
								?>
								}'>0</div>
                                    </div>
                                    <div class="col-12">
                                        <hr class="border-dashed border-bottom-0">
                                    </div>
                                    <div class="card-header bg-transparent">
                                        <h5 class="text-white">Verification Successful</h5>
                                        <div class="real-time-user display-1 font-weight-normal fs-4 text-white" data-countup='{"count":
										
										<?php							
								$stmt = "SELECT count(*) as total from rs_applications WHERE rs_users_id = '$user_id' AND application_status = 'Verification Successful'";
								
								$result = mysqli_query($link, $stmt);
								
								while($row = mysqli_fetch_assoc($result)) {
									echo $row["total"];
								}
								?>
								
										}'>0</div>
                                    </div>
                                    <div class="col-12">
                                        <hr class="border-dashed border-bottom-0">
                                    </div>
                                    <div class="card-header bg-transparent">
                                        <h5 class="text-white">In Progress</h5>
                                        <div class="real-time-user display-1 font-weight-normal fs-4 text-white" data-countup='{"count":
										
										<?php							
								$stmt = "SELECT count(*) as total from rs_applications WHERE rs_users_id = '$user_id' AND application_status = 'InProgress'";
								
								$result = mysqli_query($link, $stmt);
								
								while($row = mysqli_fetch_assoc($result)) {
									echo $row["total"];
								}
								?>
										
										}'>0</div>
                                    </div>
                                    <div class="col-12">
                                        <hr class="border-dashed border-bottom-0">
                                    </div>
                                    <div class="card-header bg-transparent">
                                        <h5 class="text-white">Verification Failed</h5>
                                        <div class="real-time-user display-1 font-weight-normal fs-4 text-white" data-countup='{"count":
										
										<?php							
								$stmt = "SELECT count(*) as total from rs_applications WHERE rs_users_id = '$user_id' AND application_status = 'Verification Failed'";
								
								$result = mysqli_query($link, $stmt);
								
								while($row = mysqli_fetch_assoc($result)) {
									echo $row["total"];
								}
								?>
										
										}'>0</div>
                                    </div>
                                    <div class="col-12">
                                        <hr class="border-dashed border-bottom-0">
                                    </div>
                                    <div class="card-header bg-transparent">
                                        <h5 class="text-white">Not Submitted</h5>
                                        <div class="real-time-user display-1 font-weight-normal fs-4 text-white" data-countup='{"count":
										<?php							
								$stmt = "SELECT count(*) as total from rs_applications WHERE rs_users_id = '$user_id' AND application_status = 'Not Submitted'";
								
								$result = mysqli_query($link, $stmt);
								
								while($row = mysqli_fetch_assoc($result)) {
									echo $row["total"];
								}
								
								mysqli_close($link);
								
								?>
								}'>0</div>
                                    </div>
                                </center>
                            </div>
                        </div>
                        <div class="col-lg-8 pr-0 pr-lg-2">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="mb-0">Chart View</h5>
                                </div>
                                <!-- HTML -->
                                <div id="chartdiv"></div>
                            </div>
                        </div>
                    </div>
                    <footer>
                        <div class="row no-gutters justify-content-between fs--1 mt-4 mb-3"></div>
                    </footer>
                </div>
            </div>
        </main>
        <!-- ===============================================-->
        <!--    End of Main Content-->
        <!-- ===============================================-->
        <!-- ===============================================-->
        <!--    JavaScripts-->
        <!-- ===============================================-->
        <script src="https://canvasjs.com/assets/script/jquery-1.11.1.min.js"></script>
        <script src="https://canvasjs.com/assets/script/jquery.canvasjs.min.js"></script>
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.js"></script>
        <script src="assets/lib/stickyfilljs/stickyfill.min.js"></script>
        <script src="assets/lib/sticky-kit/sticky-kit.min.js"></script>
        <script src="assets/lib/is_js/is.min.js"></script>
        <script src="assets/lib/@fortawesome/all.min.js"></script>
        <script src="assets/lib/chart.js/Chart.min.js"></script>
        <script src="assets/lib/jqvmap/jquery.vmap.js"></script>
        <script src="assets/lib/jqvmap/maps/jquery.vmap.world.js" charset="utf-8"></script>
        <script src="assets/lib/jqvmap/maps/jquery.vmap.usa.js" charset="utf-8"></script>
        <script src="assets/lib/datatables/js/jquery.dataTables.min.js"></script>
        <script src="assets/lib/datatables-bs4/dataTables.bootstrap4.min.js"></script>
        <script src="assets/lib/datatables.net-responsive/dataTables.responsive.js"></script>
        <script src="assets/lib/datatables.net-responsive-bs4/responsive.bootstrap4.js"></script>
        <script src="assets/lib/chart.js/Chart.min.js"></script>
        <script src="assets/js/theme.js"></script>

		
<script>
$(document).ready(function(){
  $("#myInput").on("keyup", function() {
    var value = $(this).val().toLowerCase();
    $("#purchases tr").filter(function() {
      $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
    });
  });
});
</script>

		
    </body>
</html>