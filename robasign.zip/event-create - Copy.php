<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: /");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en-US" dir="ltr">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <!-- ===============================================-->
    <!--    Document Title-->
    <!-- ===============================================-->
    <title>Create Application | Robasign</title>


    <!-- ===============================================-->
    <!--    Favicons-->
    <!-- ===============================================-->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/favicon-16x16.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicons/favicon.ico">
    <link rel="manifest" href="assets/img/favicons/manifest.json">
    <meta name="msapplication-TileImage" content="assets/img/favicons/mstile-150x150.png">
    <meta name="theme-color" content="#ffffff">


    <!-- ===============================================-->
    <!--    Stylesheets-->
    <!-- ===============================================-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700%7cPoppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="assets/lib/select2/select2.min.css" rel="stylesheet">
    <link href="assets/lib/flatpickr/flatpickr.min.css" rel="stylesheet">
    <link href="assets/css/theme.css" rel="stylesheet">

  </head>


  <body>

    <!-- ===============================================-->
    <!--    Main Content-->
    <!-- ===============================================-->
    <main class="main" id="top">


      <div class="container-fluid">
        <?php include 'menu.php'; ?>
        <div class="content">
          <?php include 'header_bar.php'; ?>
          <div class="card mb-3">
            <div class="card-body">
              <div class="row justify-content-between align-items-center">
                <div class="col-md">
                  <h5 class="mb-2 mb-md-0">Create Application</h5>
                </div>
                <div class="col-auto">
                </div>
              </div>
            </div>
          </div>
		  
<?php

// Include config file
require_once "config.php";

if (isset($_POST['submit'])) {

// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
	
	// prepare and bind
	$stmt = $link->prepare("INSERT INTO rs_applications (firstname, lastname, mobile, email, address1, address2, city, state, zip, description, product_type, rs_users_id, application_status)
			VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
	
	$stmt->bind_param("sssssssssssss", $fname, $lname, $mobile, $email, $address1, $address2, $city, $county, $postcode, $description, $productType, $user_id, $application_status);
	
	$fname = trim($_POST["first-name"]);
	$lname = trim($_POST["last-name"]);
	$mobile = trim($_POST["mobile"]);
	$email = trim($_POST["email"]);
	$address1 = trim($_POST["address1"]);
	$address2 = trim($_POST["address2"]);
	$city = trim($_POST["city"]);
	$county = trim($_POST["county"]);
	$postcode = trim($_POST["post-code"]);
	$description = trim($_POST["description"]);
	$productType = trim($_POST["product-type"]);
	$user_id = trim($_SESSION['id']);
	$application_status = "InProgress";
	
	if ($stmt->execute()) {
		$last_id = $link->insert_id;
	?>
	<div id="successMessages" class="alert alert-success alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		<div id="messages_content"><?php echo"Application Reference ID: $last_id has been Succesfully created"; ?> <?php //echo $last_id; ?></div>
    </div>
	<?php } else {
		
		?>
		
		<div id="failMessages" class="alert alert-danger alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <div id="messages_content"><?php echo"Application Saving Failed"; ?></div>
        </div>
<?php
	}

	$filesToZip = array();
	$output_dir = "Main Folder/In Progress Applications/";
    $fileCount = count($_FILES["image"]['name']);
	for($i=0; $i < $fileCount; $i++) {
            $RandomNum   = time();
        
            $ImageName      = str_replace(' ','-',strtolower($_FILES['image']['name'][$i]));
            $ImageType      = $_FILES['image']['type'][$i];
         
            $ImageExt = substr($ImageName, strrpos($ImageName, '.'));
            $ImageExt       = str_replace('.','',$ImageExt);
            $ImageName      = preg_replace("/\.[^.\s]{3,4}$/", "", $ImageName);
            $NewImageName = $ImageName.'-'.$RandomNum.'.'.$ImageExt;
            
            $ret[$NewImageName]= $output_dir.$NewImageName;
			array_push($filesToZip, $ImageName);
            
            /* Try to create the directory if it does not exist */////
			if (!file_exists($output_dir . $last_id)) {
				@mkdir($output_dir . $last_id, 0777);
			}
                        
            move_uploaded_file($_FILES["image"]["tmp_name"][$i],$output_dir.$last_id."/".$NewImageName );
    }
	$zip = new ZipArchive;
    $download = "Main Folder/In Progress Applications/".$last_id.".zip";
	//echo $download;
    $zip->open($download, ZipArchive::CREATE);
    foreach (glob("Main Folder/In Progress Applications/$last_id/*.pdf") as $file) { /* Add appropriate path to read content of zip */
        $new_filename = substr($file,strrpos($file,'/') + 1);
		$zip->addFile($file,$new_filename);
    }
    $zip->close();	
	
	$files = glob("Main Folder/In Progress Applications/$last_id/*"); // get all file names
foreach($files as $file){ // iterate files
  if(is_file($file))
    unlink($file); // delete file
}

	$dirname = 	"Main Folder/In Progress Applications/$last_id";
	rmdir($dirname); // delete folder
	
	$stmt->close();
	$link->close();
}
} elseif (isset($_POST['save'])) {
	
	// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
	
	// prepare and bind
	$stmt = $link->prepare("INSERT INTO rs_applications (firstname, lastname, mobile, email, address1, address2, city, state, zip, description, product_type, rs_users_id, application_status)
			VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
	
	$stmt->bind_param("sssssssssssss", $fname, $lname, $mobile, $email, $address1, $address2, $city, $county, $postcode, $description, $productType, $user_id, $application_status);
	
	$fname = trim($_POST["first-name"]);
	$lname = trim($_POST["last-name"]);
	$mobile = trim($_POST["mobile"]);
	$email = trim($_POST["email"]);
	$address1 = trim($_POST["address1"]);
	$address2 = trim($_POST["address2"]);
	$city = trim($_POST["city"]);
	$county = trim($_POST["county"]);
	$postcode = trim($_POST["post-code"]);
	$description = trim($_POST["description"]);
	$productType = trim($_POST["product-type"]);
	$user_id = trim($_SESSION['id']);
	$application_status = "Not Submitted";
	
	if ($stmt->execute()) {
		$last_id = $link->insert_id;
	?>
	<div id="successMessages" class="alert alert-success alert-dismissible" role="alert">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		<div id="messages_content"><?php echo"Application Reference ID: $last_id has been Succesfully Saved"; ?> <?php //echo $last_id; ?></div>
    </div>
	<?php } else {
		
		?>
		
		<div id="failMessages" class="alert alert-danger alert-dismissible" role="alert">
              <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
              <div id="messages_content"><?php echo"Application Saving Failed"; ?></div>
        </div>
<?php
	}

	$filesToZip = array();
	$output_dir = "Main Folder/Not Started Applications/";
    $fileCount = count($_FILES["image"]['name']);
	for($i=0; $i < $fileCount; $i++) {
            $RandomNum   = time();
        
            $ImageName      = str_replace(' ','-',strtolower($_FILES['image']['name'][$i]));
            $ImageType      = $_FILES['image']['type'][$i];
         
            $ImageExt = substr($ImageName, strrpos($ImageName, '.'));
            $ImageExt       = str_replace('.','',$ImageExt);
            $ImageName      = preg_replace("/\.[^.\s]{3,4}$/", "", $ImageName);
            $NewImageName = $ImageName.'-'.$RandomNum.'.'.$ImageExt;
            
            $ret[$NewImageName]= $output_dir.$NewImageName;
			array_push($filesToZip, $ImageName);
            
            /* Try to create the directory if it does not exist */////
			if (!file_exists($output_dir . $last_id)) {
				@mkdir($output_dir . $last_id, 0777);
			}
                        
            move_uploaded_file($_FILES["image"]["tmp_name"][$i],$output_dir.$last_id."/".$NewImageName );
    }
	
	$stmt->close();
	$link->close();
}
	
}
?>
          <div class="row no-gutters">
            <div class="col-lg-6 pr-lg-2">
              <div class="card mb-3">
                <div class="card-header">
                  <h5 class="mb-0">Application Details</h5>
                </div>
                <div class="card-body bg-light">
                  <form id="app-form" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data">
                    <div class="form-row">
                      <div class="col-6">
                        <div class="form-group">
                          <label for="event-name">First Name</label>
                          <input class="form-control" id="first-name" name="first-name" type="text" placeholder="First Name" required>
                        </div>
                      </div>
					  <div class="col-6">
                        <div class="form-group">
                          <label for="event-name">Last Name</label>
                          <input class="form-control" id="last-name" name="last-name" type="text" placeholder="Last Name" required>
                        </div>
                      </div>
					  <div class="col-6">
                        <div class="form-group">
                          <label for="event-name">Mobile</label>
                          <input class="form-control" id="mobile" name="mobile" type="text" placeholder="Mobile">
                        </div>
                      </div>
					  <div class="col-6">
                        <div class="form-group">
                          <label for="event-name">Email</label>
                          <input class="form-control" id="email" name="email" type="email" placeholder="Email" required>
                        </div>
                      </div>
                      <div class="col-12">
                        <hr class="border-dashed border-bottom-0">
                      </div>
                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="event-address">Address 1</label>
                          <input class="form-control" id="address1" name="address1" type="text" placeholder="Address 1" required>
                        </div>
                      </div>
					  <div class="col-sm-6">
                        <div class="form-group">
                          <label for="event-address">Address 2</label>
                          <input class="form-control" id="address2" name="address2" type="text" placeholder="Address 2">
                        </div>
                      </div>
                      <div class="col-sm-4">
                        <div class="form-group">
                          <label for="event-city">City</label>
                          <input class="form-control" id="city" name="city" type="text" placeholder="City" required>
                        </div>
                      </div>
                      <div class="col-sm-4">
                        <div class="form-group">
                          <label for="event-state">County</label>
                          <input class="form-control" id="county" name="county" type="text" placeholder="County" required>
                        </div>
                      </div>
                      <div class="col-sm-4">
                        <div class="form-group">
                          <label for="event-country">Post Code</label>
                          <input class="form-control" id="post-code" name="post-code" type="text" placeholder="Post Code" required>
                        </div>
                      </div>
                      <div class="col-12">
                        <div class="form-group">
                          <label for="event-description">Description</label>
                          <textarea class="form-control" id="description" name="description" rows="6" required> </textarea>
                        </div>
                      </div>
                    </div>
                <!--  </form> -->
                </div>
              </div>
            </div>
            <div class="col-lg-6 pl-lg-2">
              <!-- <div class="sticky-top sticky-sidebar"> -->
                <div class="card mb-3">
                  <div class="card-header">
                    <h5 class="mb-0">Other Info</h5>
					</div>
					<div class="card-body bg-light">
                    <div class="form-group">
                      <label for="event-type">Product Type</label>
                      <select class="custom-select" id="product-type" name="product-type" required>
                        <option value="">Select Product Type</option>
                        <option value="Residential">Residential</option>
                        <option value="Commercial">Commercial</option>
                        <option value="Bridging">Bridging</option>
                      </select>
					</div>
                    </div>
                </div>
				<div class="card mb-3">
                  <div class="card-header">
                    <h5 class="mb-0">Company Info</h5>
					</div>
					<div class="card-body bg-light">
                    <div class="form-group">
                      <div class="col-sm-6">
                        <div class="form-group">
                          <label for="event-address">Address 1</label>
                          <input class="form-control" id="address1" name="address1" type="text" placeholder="Address 1" required>
                        </div>
                      </div>
					  <div class="col-sm-6">
                        <div class="form-group">
                          <label for="event-address">Address 2</label>
                          <input class="form-control" id="address2" name="address2" type="text" placeholder="Address 2">
                        </div>
                      </div>
					</div>
                    </div>
                </div>
                <div class="card mb-3">
                  <div class="card-header">
                    <h5 class="mb-0">Upload Documents</h5>
					</div>
					<div class="card-body bg-light">
                    <div class="row no-gutters">
                    <div class="col-md-6 mb-3">
                        <div class="form-group">
                          <label for="event-country">Bank Statement 1</label>
                          <input class="form-control-file" id="bankStatement1" name="image[]" type="file">
                        </div>
                      </div>
                      <div class="col-md-6 mb-3">
                      	<div class="form-group">
                          <label for="event-country">Payslip 1</label>
                          <input class="form-control-file" id="payslip1" name="image[]" type="file">
                        </div>
                    </div>
                      <div class="col-md-6 mb-3">
                        <div class="form-group">
                          <label for="event-country">Bank Statement 2</label>
                          <input class="form-control-file" id="bankStatement2" name="image[]" type="file">
                        </div>
                        </div>
                      <div class="col-md-6 mb-3">
                      	<div class="form-group">
                          <label for="event-country">Payslip 2</label>
                          <input class="form-control-file" id="payslip2" name="image[]" type="file">
                        </div>
                    </div>
                      <div class="col-md-6 mb-3">
                        <div class="form-group">
                          <label for="event-country">Bank Statement 3</label>
                          <input class="form-control-file" id="bankStatement3" name="image[]" type="file">
                        </div>
                        </div>
                      <div class="col-md-6 mb-3">
                      	<div class="form-group">
                          <label for="event-country">Payslip 3</label>
                          <input class="form-control-file" id="payslip3" name="image[]" type="file">
                        </div>
                    </div>
                      </div>
                  </div>
                </div>
              </div>
            </div>
          <!-- </div> -->
          <div class="card mt-3">
            <div class="card-body">
              <div class="row justify-content-between align-items-center">
                <div class="col-md">
                  <h5 class="mb-2 mb-md-0">Nice Job! You're almost done</h5>
                </div>
                <div class="col-auto">
                  <button id="save" name="save" class="btn btn-falcon-default btn-md mr-2" type="submit" role="button">Save</button>
                  <button id="submit" name="submit" class="btn btn-falcon-primary btn-md" type="submit" role="button" disabled>Submit</button>
                </div>
              </div>
            </div>
          </div>
</form>
          <footer>
            <div class="row no-gutters justify-content-between fs--1 mt-4 mb-3">
            </div>
          </footer>
        </div>
      </div>
    </main>
    <!-- ===============================================-->
    <!--    End of Main Content-->
    <!-- ===============================================-->




    <!-- ===============================================-->
    <!--    JavaScripts-->
    <!-- ===============================================-->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.js"></script>
    <script src="assets/lib/stickyfilljs/stickyfill.min.js"></script>
    <script src="assets/lib/sticky-kit/sticky-kit.min.js"></script>
    <script src="assets/lib/is_js/is.min.js"></script>
    <script src="assets/lib/@fortawesome/all.min.js"></script>
    <script src="assets/lib/select2/select2.min.js"></script>
    <script src="assets/lib/flatpickr/flatpickr.min.js"></script>
    <script src="assets/js/theme.js"></script>

<script>

</script>

<script>
$('input[type=file]').change(function(){
    if($('#bankStatement1').val()=='' || $('#bankStatement2').val()=='' || $('#bankStatement3').val()=='' || $('#payslip1').val()=='' || $('#payslip2').val()=='' || $('#payslip3').val()==''){
    	$('#submit').attr('disabled',true)
    } 
    else{
      $('#submit').attr('disabled',false);
    }
})
</script>

  </body>

</html>