<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en-US" dir="ltr">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <!-- ===============================================-->
    <!--    Document Title-->
    <!-- ===============================================-->
    <title>Notifications | Robasign</title>


    <!-- ===============================================-->
    <!--    Favicons-->
    <!-- ===============================================-->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/favicon-16x16.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicons/favicon.ico">
    <link rel="manifest" href="assets/img/favicons/manifest.json">
    <meta name="msapplication-TileImage" content="assets/img/favicons/mstile-150x150.png">
    <meta name="theme-color" content="#ffffff">


    <!-- ===============================================-->
    <!--    Stylesheets-->
    <!-- ===============================================-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700%7cPoppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="assets/lib/remodal/remodal.css" rel="stylesheet">
    <link href="assets/lib/remodal/remodal-default-theme.css" rel="stylesheet">
    <link href="assets/css/theme.css" rel="stylesheet">

  </head>


  <body>

    <!-- ===============================================-->
    <!--    Main Content-->
    <!-- ===============================================-->
    <main class="main" id="top">


      <div class="container-fluid">
        <?php include 'menu.php'; ?>
        <div class="content">
          <?php include 'header_bar.php'; ?>
          <div class="card overflow-hidden mb-3">
            <div class="card-header bg-light">
              <div class="row justify-content-between align-items-center">
                <div class="col-sm-auto">
                  <h5 class="mb-1 mb-md-0">Your Notifications</h5>
                </div>
                <div class="col-sm-auto fs--1"><a class="text-sans-serif" href="notifications">Mark all as read</a><a class="text-sans-serif ml-2 ml-sm-3" href="#!" data-remodal-target="modal">Notification settings</a></div>
              </div>
            </div>
            <div class="card-body fs--1 p-0">
              <a class="border-bottom-0 notification rounded-0 border-x-0 border-300" href="#!">
                <div class="notification-avatar">
                  <div class="avatar avatar-xl mr-3">
                    

                  </div>
                </div>
                <div class="notification-body">
                  <p class="mb-1">Application Submission Pending:<strong> Application No 34 has not submitted for analysing</strong> </p>
                  <span class="notification-time"><span style="color:#eb860c;" class="mr-1" role="img" aria-label="Emoji"><i class="fas fa-exclamation-triangle"></i></span>Just Now</span>

                </div>
              </a>

              <a class="border-bottom-0 bg-200 notification rounded-0 border-x-0 border-300" href="#!">
                <div class="notification-avatar">
                  <div class="avatar avatar-xl mr-3">
                    

                  </div>
                </div>
                <div class="notification-body">
                  <p class="mb-1">Application Status:<strong> Verification Successful</strong>! Your Application No 12 was successfully verified</p>
                  <span class="notification-time"><span style="color:#208ee8;" class="mr-1" role="img" aria-label="Emoji"><i class="fas fa-file-alt"></i></span>15 minutes ago</span>

                </div>
              </a>

              <a class="border-bottom-0 notification rounded-0 border-x-0 border-300" href="#!">
                <div class="notification-avatar">
                  <div class="avatar avatar-xl mr-3">


                  </div>
                </div>
                <div class="notification-body">
                  <p class="mb-1"><strong>Subscription</strong> Your Subscription is expiring in <strong>3 Days</strong></p>
                  <span class="notification-time"><span style="color:#2ede28;" class="mr-1" role="img" aria-label="Emoji"><i class="fas fa-dollar-sign"></i></span>1h</span>

                </div>
              </a>

            </div>
          </div>
          <footer>
            <div class="row no-gutters justify-content-between fs--1 mt-4 mb-3">
            </div>
          </footer>
        </div>
        <div class="remodal rounded-soft p-0" data-remodal-id="modal">
          <div class="d-flex align-items-center border-bottom p-3">
            <h4 class="mb-0">Notification Settings</h4>
          </div>
          <div class="remodal-body p-4">
            <form class="text-left">
              <div class="custom-control custom-radio">
                <input class="custom-control-input" type="radio" name="notification-settings" id="always" />
                <label class="custom-control-label" for="always">Get a notification each time there is activity on your page or an important update.
                </label>
              </div>
              <div class="custom-control custom-radio">
                <input class="custom-control-input" type="radio" name="notification-settings" id="everyday" />
                <label class="custom-control-label" for="everyday">Get one notification every 12-24 hours on all activity and updates.
                </label>
              </div>
              <div class="custom-control custom-radio">
                <input class="custom-control-input" type="radio" name="notification-settings" id="off" />
                <label class="custom-control-label" for="off">Off
                </label>
              </div>
              <h5 class="fs-0 mb-3 mt-4">Edit your notification settings for: </h5>
              <ul class="list-group list-group-flush mb-4 fs--1">
                <li class="list-group-item d-flex justify-content-between align-items-center py-2 px-0 border-200"><span>New Mention of Page </span><span>
                    <input class="ios-toggle" id="checkbox1" type="checkbox" name="checkbox1" checked=""/>
                    <label class="checkbox-label checkbox-label-sm" for="checkbox1" data-off="" data-on=""></label></span></li>
                <li class="list-group-item d-flex justify-content-between align-items-center py-2 px-0 border-200"><span>New Comments on page post</span><span>
                    <input class="ios-toggle" id="checkbox2" type="checkbox" name="checkbox2" checked=""/>
                    <label class="checkbox-label checkbox-label-sm" for="checkbox2" data-off="" data-on=""></label></span></li>
                <li class="list-group-item d-flex justify-content-between align-items-center py-2 px-0 border-200"><span>Edits to Comments you have written</span><span>
                    <input class="ios-toggle" id="checkbox3" type="checkbox" name="checkbox3" checked=""/>
                    <label class="checkbox-label checkbox-label-sm" for="checkbox3" data-off="" data-on=""></label></span></li>
              </ul>
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input" type="checkbox" id="followers-activity" />
                <label class="custom-control-label" for="followers-activity">Allow notifications from your followers activity
                </label>
              </div>
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input" type="checkbox" id="groups" />
                <label class="custom-control-label" for="groups">Groups
                </label>
              </div>
              <div class="custom-control custom-checkbox">
                <input class="custom-control-input" type="checkbox" id="associations" />
                <label class="custom-control-label" for="associations">Associations
                </label>
              </div>
            </form>
          </div>
          <div class="remodal-footer border-top text-left py-3 px-4 d-flex justify-content-end">
            <button class="btn btn-secondary btn-sm" data-remodal-action="close">Cancel</button>
            <button class="btn btn-primary btn-sm ml-2" type="submit">Update</button>
          </div>
        </div>
      </div>
    </main>
    <!-- ===============================================-->
    <!--    End of Main Content-->
    <!-- ===============================================-->




    <!-- ===============================================-->
    <!--    JavaScripts-->
    <!-- ===============================================-->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.js"></script>
    <script src="assets/lib/stickyfilljs/stickyfill.min.js"></script>
    <script src="assets/lib/sticky-kit/sticky-kit.min.js"></script>
    <script src="assets/lib/is_js/is.min.js"></script>
    <script src="assets/lib/@fortawesome/all.min.js"></script>
    <script src="assets/lib/remodal/remodal.min.js"></script>
    <script src="assets/js/theme.js"></script>

  </body>

</html>
