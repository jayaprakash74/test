<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: /");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en-US" dir="ltr">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <!-- ===============================================-->
    <!--    Document Title-->
    <!-- ===============================================-->
    <title>Customer Details | Robasign</title>


    <!-- ===============================================-->
    <!--    Favicons-->
    <!-- ===============================================-->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/favicon-16x16.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicons/favicon.ico">
    <link rel="manifest" href="assets/img/favicons/manifest.json">
    <meta name="msapplication-TileImage" content="assets/img/favicons/mstile-150x150.png">
    <meta name="theme-color" content="#ffffff">


    <!-- ===============================================-->
    <!--    Stylesheets-->
    <!-- ===============================================-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700%7cPoppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="assets/css/theme.css" rel="stylesheet">

  </head>


  <body>

    <!-- ===============================================-->
    <!--    Main Content-->
    <!-- ===============================================-->
    <main class="main" id="top">


      <div class="container-fluid">
        <?php include 'menu.php'; ?>
        <div class="content">
          <?php include 'header_bar.php'; ?>
          <div class="card mb-3">
            <div class="card-header">
              <div class="row">
                <div class="col">
                  <h5 class="mb-2">Tony Robbins (<a href="mailto:tony@gmail.com">tony@gmail.com</a>)</h5><a class="btn btn-falcon-default btn-sm" href="#!"><span class="fas fa-plus fs--2 mr-1"></span>Add note</a>
                  <button class="btn btn-falcon-default btn-sm dropdown-toggle ml-2 dropdown-caret-none" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><span class="fas fa-ellipsis-h"></span></button>
                  <div class="dropdown-menu"><a class="dropdown-item" href="#">Edit</a><a class="dropdown-item" href="#">Report</a><a class="dropdown-item" href="#">Archive</a>
                    <div class="dropdown-divider"></div><a class="dropdown-item text-danger" href="#">Delete user</a>
                  </div>
                </div>
                <div class="col-auto d-none d-sm-block">
                  <h6 class="text-uppercase text-600">Customer<span class="fas fa-user ml-2"></span></h6>
                </div>
              </div>
            </div>
            <div class="card-body border-top">
              <div class="media"><span class="fas fa-user text-success mr-2" data-fa-transform="down-5"></span>
                <div class="media-body">
                  <p class="mb-0">Customer was created</p>
                  <p class="fs--1 mb-0 text-600">Jan 12, 11:13 PM</p>
                </div>
              </div>
            </div>
          </div>
          <div class="card mb-3">
            <div class="card-header">
              <div class="row align-items-center">
                <div class="col">
                  <h5 class="mb-0">Details</h5>
                </div>
                <div class="col-auto"><a class="btn btn-falcon-default btn-sm" href="#!"><span class="fas fa-pencil-alt fs--2 mr-1"></span>Update details</a></div>
              </div>
            </div>
            <div class="card-body bg-light border-top">
              <div class="row">
                <div class="col-lg col-xxl-5">
                  <h6 class="font-weight-semi-bold ls mb-3 text-uppercase">Account Information</h6>
                  <div class="row">
                    <div class="col-5 col-sm-4">
                      <p class="font-weight-semi-bold mb-1">ID</p>
                    </div>
                    <div class="col">dcfasyo_Dfdjl</div>
                  </div>
                  <div class="row">
                    <div class="col-5 col-sm-4">
                      <p class="font-weight-semi-bold mb-1">Created</p>
                    </div>
                    <div class="col">2019/01/12 23:13</div>
                  </div>
                  <div class="row">
                    <div class="col-5 col-sm-4">
                      <p class="font-weight-semi-bold mb-1">Email</p>
                    </div>
                    <div class="col"><a href="mailto:tony@gmail.com">tony@gmail.com</a></div>
                  </div>
                  <div class="row">
                    <div class="col-5 col-sm-4">
                      <p class="font-weight-semi-bold mb-1">Description</p>
                    </div>
                    <div class="col">
                      <p class="font-italic text-400 mb-1">No Description</p>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-5 col-sm-4">
                      <p class="font-weight-semi-bold mb-0">VAT number</p>
                    </div>
                    <div class="col">
                      <p class="font-italic text-400 mb-0">No VAT number</p>
                    </div>
                  </div>
                </div>
                <div class="col-lg col-xxl-5 mt-4 mt-lg-0 offset-xxl-1">
                  <h6 class="font-weight-semi-bold ls mb-3 text-uppercase">Billing Information</h6>
                  <div class="row">
                    <div class="col-5 col-sm-4">
                      <p class="font-weight-semi-bold mb-1">Send email to</p>
                    </div>
                    <div class="col"><a href="mailto:tony@gmail.com">tony@gmail.com</a></div>
                  </div>
                  <div class="row">
                    <div class="col-5 col-sm-4">
                      <p class="font-weight-semi-bold mb-1">Address</p>
                    </div>
                    <div class="col">
                      <p class="mb-1">8962 Lafayette St. <br>Oswego, NY 13126</p>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-5 col-sm-4">
                      <p class="font-weight-semi-bold mb-1">Phone number</p>
                    </div>
                    <div class="col"><a href="tel:+12025550110">+1-202-555-0110</a></div>
                  </div>
                  <div class="row">
                    <div class="col-5 col-sm-4">
                      <p class="font-weight-semi-bold mb-0">Invoice prefix</p>
                    </div>
                    <div class="col">
                      <p class="font-weight-semi-bold mb-0">7C23435</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="card-footer border-top text-right"><a class="btn btn-falcon-default btn-sm" href="#!"><span class="fas fa-dollar-sign fs--2 mr-1"></span>Refund</a><a class="btn btn-falcon-default btn-sm ml-2" href="#!"><span class="fas fa-check fs--2 mr-1"></span>Save changes</a></div>
          </div>
          <div class="card">
            <div class="card-header">
              <h5 class="mb-0">Logs</h5>
            </div>
            <div class="card-body border-top p-0">
              <div class="row no-gutters align-items-center border-bottom py-2 px-3">
                <div class="col-md-auto pr-3"><span class="badge badge-soft-success badge-pill">200</span></div>
                <div class="col-md mt-1 mt-md-0"><code>POST /v1/invoiceitems</code></div>
                <div class="col-md-auto">
                  <p class="mb-0">2019/02/23 15:29:45</p>
                </div>
              </div>
              <div class="row no-gutters align-items-center border-bottom py-2 px-3">
                <div class="col-md-auto pr-3"><span class="badge badge-soft-warning badge-pill">400</span></div>
                <div class="col-md mt-1 mt-md-0"><code>POST /v1/invoiceitems</code></div>
                <div class="col-md-auto">
                  <p class="mb-0">2019/02/19 21:32:12</p>
                </div>
              </div>
              <div class="row no-gutters align-items-center border-bottom py-2 px-3">
                <div class="col-md-auto pr-3"><span class="badge badge-soft-success badge-pill">200</span></div>
                <div class="col-md mt-1 mt-md-0"><code>POST /v1/invoices/in_1Dnkhadfk</code></div>
                <div class="col-md-auto">
                  <p class="mb-0">2019/02/26 12:23:43</p>
                </div>
              </div>
              <div class="row no-gutters align-items-center border-bottom py-2 px-3">
                <div class="col-md-auto pr-3"><span class="badge badge-soft-success badge-pill">200</span></div>
                <div class="col-md mt-1 mt-md-0"><code>POST /v1/invoices/in_1Dnkhadfk</code></div>
                <div class="col-md-auto">
                  <p class="mb-0">2019/02/12 23:32:12</p>
                </div>
              </div>
              <div class="row no-gutters align-items-center border-bottom py-2 px-3">
                <div class="col-md-auto pr-3"><span class="badge badge-soft-danger badge-pill">404</span></div>
                <div class="col-md mt-1 mt-md-0"><code>POST /v1/invoices/in_1Dnkhadfk</code></div>
                <div class="col-md-auto">
                  <p class="mb-0">2019/02/08 02:20:23</p>
                </div>
              </div>
              <div class="row no-gutters align-items-center border-bottom py-2 px-3">
                <div class="col-md-auto pr-3"><span class="badge badge-soft-success badge-pill">200</span></div>
                <div class="col-md mt-1 mt-md-0"><code>POST /v1/invoices/in_1Dnkhadfk</code></div>
                <div class="col-md-auto">
                  <p class="mb-0">2019/02/01 12:29:34</p>
                </div>
              </div>
            </div>
            <div class="card-footer bg-light p-0"><a class="btn btn-link btn-block" href="#!">View more logs<span class="fas fa-chevron-right fs--2 ml-1"></span></a></div>
          </div>
          <footer>
            <div class="row no-gutters justify-content-between fs--1 mt-4 mb-3">
              <div class="col-12 col-sm-auto text-center">
                <p class="mb-0 text-600">Thank you for creating with Falcon <span class="d-none d-sm-inline-block">| </span><br class="d-sm-none" /> 2019 &copy; <a href="https://themewagon.com">Themewagon</a></p>
              </div>
              <div class="col-12 col-sm-auto text-center">
                <p class="mb-0 text-600">v1.8.1</p>
              </div>
            </div>
          </footer>
        </div>
        <div class="modal fade" id="authentication-modal" tabindex="-1" role="dialog" aria-labelledby="authentication-modal-label" aria-hidden="true">
          <div class="modal-dialog mt-6" role="document">
            <div class="modal-content border-0">
              <div class="modal-header px-5 text-white position-relative modal-shape-header">
                <div class="position-relative z-index-1">
                  <div>
                    <h4 class="mb-0 text-white" id="authentication-modal-label">Register</h4>
                    <p class="fs--1 mb-0">Please create your free Falcon account</p>
                  </div>
                </div>
                <button class="close text-white position-absolute t-0 r-0 mt-1 mr-1" data-dismiss="modal" aria-label="Close"><span class="font-weight-light" aria-hidden="true">&times;</span></button>
              </div>
              <div class="modal-body py-4 px-5">
                <form>
                  <div class="form-group">
                    <label for="modal-auth-name">Name</label>
                    <input class="form-control" type="text" id="modal-auth-name" />
                  </div>
                  <div class="form-group">
                    <label for="modal-auth-email">Email</label>
                    <input class="form-control" type="email" id="modal-auth-email" />
                  </div>
                  <div class="form-row">
                    <div class="form-group col-6">
                      <label for="modal-auth-password">Password</label>
                      <input class="form-control" type="password" id="modal-auth-password" />
                    </div>
                    <div class="form-group col-6">
                      <label for="modal-auth-confirm-password">Confirm Password</label>
                      <input class="form-control" type="password" id="modal-auth-confirm-password" />
                    </div>
                  </div>
                  <div class="custom-control custom-checkbox">
                    <input class="custom-control-input" type="checkbox" id="modal-auth-register-checkbox" />
                    <label class="custom-control-label" for="modal-auth-register-checkbox">I accept the <a href="#!">terms </a>and <a href="#!">privacy policy</a></label>
                  </div>
                  <div class="form-group">
                    <button class="btn btn-primary btn-block mt-3" type="submit" name="submit">Register</button>
                  </div>
                </form>
                <div class="w-100 position-relative mt-5">
                  <hr class="text-300" />
                  <div class="position-absolute absolute-centered t-0 px-3 bg-white text-sans-serif fs--1 text-500 text-nowrap">or sign-up with</div>
                </div>
                <div class="form-group mb-0">
                  <div class="row no-gutters">
                    <div class="col-sm-6 pr-sm-1"><a class="btn btn-outline-google-plus btn-sm btn-block mt-2" href="#"><span class="fab fa-google-plus-g mr-2" data-fa-transform="grow-8"></span> google</a></div>
                    <div class="col-sm-6 pl-sm-1"><a class="btn btn-outline-facebook btn-sm btn-block mt-2" href="#"><span class="fab fa-facebook mr-2" data-fa-transform="grow-8"></span> facebook</a></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
    <!-- ===============================================-->
    <!--    End of Main Content-->
    <!-- ===============================================-->




    <!-- ===============================================-->
    <!--    JavaScripts-->
    <!-- ===============================================-->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.js"></script>
    <script src="assets/lib/stickyfilljs/stickyfill.min.js"></script>
    <script src="assets/lib/sticky-kit/sticky-kit.min.js"></script>
    <script src="assets/lib/is_js/is.min.js"></script>
    <script src="assets/lib/@fortawesome/all.min.js"></script>
    <script src="assets/js/theme.js"></script>

  </body>

</html>