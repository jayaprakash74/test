<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: /");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en-US" dir="ltr">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <!-- ===============================================-->
    <!--    Document Title-->
    <!-- ===============================================-->
    <title>Billing | Robasign</title>


    <!-- ===============================================-->
    <!--    Favicons-->
    <!-- ===============================================-->
    <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/favicon-16x16.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicons/favicon.ico">
    <link rel="manifest" href="assets/img/favicons/manifest.json">
    <meta name="msapplication-TileImage" content="assets/img/favicons/mstile-150x150.png">
    <meta name="theme-color" content="#ffffff">


    <!-- ===============================================-->
    <!--    Stylesheets-->
    <!-- ===============================================-->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700%7cPoppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
    <link href="assets/css/theme.css" rel="stylesheet">

  </head>


  <body>

    <!-- ===============================================-->
    <!--    Main Content-->
    <!-- ===============================================-->
    <main class="main" id="top">


      <div class="container-fluid">
        <?php include 'menu.php'; ?>
        <div class="content">
          <?php include 'header_bar.php'; ?>
          <div class="card mb-3">
            <div class="bg-holder d-none d-lg-block bg-card" style="background-image:url(assets/img/illustrations/corner-4.png);">
            </div>
            <!--/.bg-holder-->

            <div class="card-body">
              <div class="row">
                <div class="col-lg-8">
                  <h3 class="mb-0">Get started with your free trial</h3>
                  <p class="mt-2">Premium team - 5 Seats. Free for 30 days, cancel at any time. <br>$6.25 / seat month after a trial</p>
                  <div class="dropdown">
                    <button class="btn btn-link dropdown-toggle pl-0 btn-sm" id="change-plan" type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Change plan</button>
                    <div class="dropdown-menu py-0" aria-labelledby="change-plan" style="min-width: 15rem;">
                      <div class="bg-white py-3 rounded-soft">
                        <div class="dropdown-item text-base px-3 py-2"><span class="d-flex justify-content-between fs--1 text-black"><span class="font-weight-semi-bold">Standard License</span><span>$59.00</span></span>
                          <ul class="list-unstyled pl-1 my-2 fs--1">
                            <li> <span class="fas fa-circle" data-fa-transform="shrink-11"></span><span class="ml-1">Use for a single product</span></li>
                            <li><span class="fas fa-circle" data-fa-transform="shrink-11"></span><span class="ml-1">Non-paying users only</span></li>
                          </ul>
                          <p class="fs--2 mb-0">Read the full <a href="#!">Standard License </a></p>
                        </div>
                        <div class="dropdown-divider my-0"></div>
                        <div class="dropdown-item text-base px-3 py-2"><span class="d-flex justify-content-between fs--1 text-black"><span class="font-weight-semi-bold">Extended License</span><span>$99.00</span></span>
                          <ul class="list-unstyled pl-1 my-2 fs--1">
                            <li> <span class="fas fa-circle" data-fa-transform="shrink-11"></span><span class="ml-1">Unlimited websites</span></li>
                            <li> <span class="fas fa-circle" data-fa-transform="shrink-11"></span><span class="ml-1">Paying users allowed</span></li>
                          </ul>
                          <p class="fs--2 mb-0">Read the full <a href="#!">Extended License</a></p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row no-gutters">
            <div class="col-lg-8 pr-lg-2 mb-3">
              <div class="h-100 card">
                <div class="card-header">
                  <h5 class="mb-0">Billing Details</h5>
                </div>
                <div class="card-body bg-light">
                  <form class="row">
                    <div class="col">
                      <div class="custom-control custom-radio">
                        <input class="custom-control-input" type="radio" name="billing" id="paypal" />
                        <label class="custom-control-label" for="paypal"><img class="pull-right" src="assets/img/icons/icon-paypal-full.png" height="20" alt="">
                        </label>
                      </div>
                      <p class="fs--1 mb-4">Pay with PayPal, Apple Pay, PayPal Credit and much more</p>
                      <div class="custom-control custom-radio">
                        <input class="custom-control-input" type="radio" name="billing" id="credit-card" checked="checked" />
                        <label class="custom-control-label" for="credit-card"><span class="d-flex align-items-center"><span class="fs-1 text-nowrap">Credit Card</span><img class="d-none d-sm-inline-block ml-2 mt-lg-0" src="assets/img/icons/icon-payment-methods.png" height="20" alt=""></span>
                        </label>
                      </div>
                      <p class="fs--1 mb-4">Safe money transfer using your bank accounts. Visa, maestro, discover, american express.</p>
                      <div class="form-row">
                        <div class="col">
                          <div class="form-group">
                            <label class="ls text-uppercase text-600 font-weight-semi-bold mb-0" for="cardNumber">Card Number</label>
                            <input class="form-control" id="cardNumber" placeholder="XXXX XXXX XXXX XXXX" type="text" style="background-image: url(&quot;data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAABHklEQVQ4EaVTO26DQBD1ohQWaS2lg9JybZ+AK7hNwx2oIoVf4UPQ0Lj1FdKktevIpel8AKNUkDcWMxpgSaIEaTVv3sx7uztiTdu2s/98DywOw3Dued4Who/M2aIx5lZV1aEsy0+qiwHELyi+Ytl0PQ69SxAxkWIA4RMRTdNsKE59juMcuZd6xIAFeZ6fGCdJ8kY4y7KAuTRNGd7jyEBXsdOPE3a0QGPsniOnnYMO67LgSQN9T41F2QGrQRRFCwyzoIF2qyBuKKbcOgPXdVeY9rMWgNsjf9ccYesJhk3f5dYT1HX9gR0LLQR30TnjkUEcx2uIuS4RnI+aj6sJR0AM8AaumPaM/rRehyWhXqbFAA9kh3/8/NvHxAYGAsZ/il8IalkCLBfNVAAAAABJRU5ErkJggg==&quot;); background-repeat: no-repeat; background-attachment: scroll; background-size: 16px 18px; background-position: 98% 50%; cursor: auto;">
                          </div>
                        </div>
                        <div class="col">
                          <div class="form-group">
                            <label class="ls text-uppercase text-600 font-weight-semi-bold mb-0" for="cardName">Name of Card</label>
                            <input class="form-control" id="cardName" placeholder="John Doe" type="text">
                          </div>
                        </div>
                      </div>
                      <div class="form-row">
                        <div class="col-6 col-sm-3">
                          <div class="form-group">
                            <label class="ls text-uppercase text-600 font-weight-semi-bold mb-0" for="customSelectCountry">Country</label>
                            <select class="custom-select" id="customSelectCountry" name="customSelectCountry">
                              <option>Afghanistan</option>
                              <option selected>Albania</option>
                              <option>Algeria</option>
                              <option>American Samoa</option>
                              <option>Andorra</option>
                              <option>Angola</option>
                              <option>Anguilla</option>
                              <option>Antarctica</option>
                              <option>Antigua and Barbuda</option>
                              <option>Argentina</option>
                              <option>Armenia</option>
                              <option>Aruba</option>
                              <option>Australia</option>
                              <option>Austria</option>
                              <option>Azerbaijan</option>
                              <option>Bahamas</option>
                              <option>Bahrain</option>
                              <option>Bangladesh</option>
                              <option>Barbados</option>
                              <option>Belarus</option>
                              <option>Belgium</option>
                              <option>Belize</option>
                              <option>Benin</option>
                              <option>Bermuda</option>
                              <option>Bhutan</option>
                              <option>Bolivia</option>
                              <option>Bosnia and Herzegowina</option>
                              <option>Botswana</option>
                              <option>Bouvet Island</option>
                              <option>Brazil</option>
                              <option>British Indian Ocean Territory</option>
                              <option>Brunei Darussalam</option>
                              <option>Bulgaria</option>
                              <option>Burkina Faso</option>
                              <option>Burundi</option>
                              <option>Cambodia</option>
                              <option>Cameroon</option>
                              <option>Canada</option>
                              <option>Cape Verde</option>
                              <option>Cayman Islands</option>
                              <option>Central African Republic</option>
                              <option>Chad</option>
                              <option>Chile</option>
                              <option>China</option>
                              <option>Christmas Island</option>
                              <option>Cocos (Keeling) Islands</option>
                              <option>Colombia</option>
                              <option>Comoros</option>
                              <option>Congo</option>
                              <option>Congo, the Democratic Republic of the</option>
                              <option>Cook Islands</option>
                              <option>Costa Rica</option>
                              <option>Cote d'Ivoire</option>
                              <option>Croatia (Hrvatska)</option>
                              <option>Cuba</option>
                              <option>Cyprus</option>
                              <option>Czech Republic</option>
                              <option>Denmark</option>
                              <option>Djibouti</option>
                              <option>Dominica</option>
                              <option>Dominican Republic</option>
                              <option>East Timor</option>
                              <option>Ecuador</option>
                              <option>Egypt</option>
                              <option>El Salvador</option>
                              <option>Equatorial Guinea</option>
                              <option>Eritrea</option>
                              <option>Estonia</option>
                              <option>Ethiopia</option>
                              <option>Falkland Islands (Malvinas)</option>
                              <option>Faroe Islands</option>
                              <option>Fiji</option>
                              <option>Finland</option>
                              <option>France</option>
                              <option>France Metropolitan</option>
                              <option>French Guiana</option>
                              <option>French Polynesia</option>
                              <option>French Southern Territories</option>
                              <option>Gabon</option>
                              <option>Gambia</option>
                              <option>Georgia</option>
                              <option>Germany</option>
                              <option>Ghana</option>
                              <option>Gibraltar</option>
                              <option>Greece</option>
                              <option>Greenland</option>
                              <option>Grenada</option>
                              <option>Guadeloupe</option>
                              <option>Guam</option>
                              <option>Guatemala</option>
                              <option>Guinea</option>
                              <option>Guinea-Bissau</option>
                              <option>Guyana</option>
                              <option>Haiti</option>
                              <option>Heard and Mc Donald Islands</option>
                              <option>Holy See (Vatican City State)</option>
                              <option>Honduras</option>
                              <option>Hong Kong</option>
                              <option>Hungary</option>
                              <option>Iceland</option>
                              <option>India</option>
                              <option>Indonesia</option>
                              <option>Iran (Islamic Republic of)</option>
                              <option>Iraq</option>
                              <option>Ireland</option>
                              <option>Israel</option>
                              <option>Italy</option>
                              <option>Jamaica</option>
                              <option>Japan</option>
                              <option>Jordan</option>
                              <option>Kazakhstan</option>
                              <option>Kenya</option>
                              <option>Kiribati</option>
                              <option>Korea, Democratic People's Republic of</option>
                              <option>Korea, Republic of</option>
                              <option>Kuwait</option>
                              <option>Kyrgyzstan</option>
                              <option>Lao, People's Democratic Republic</option>
                              <option>Latvia</option>
                              <option>Lebanon</option>
                              <option>Lesotho</option>
                              <option>Liberia</option>
                              <option>Libyan Arab Jamahiriya</option>
                              <option>Liechtenstein</option>
                              <option>Lithuania</option>
                              <option>Luxembourg</option>
                              <option>Macau</option>
                              <option>Macedonia, The Former Yugoslav Republic of</option>
                              <option>Madagascar</option>
                              <option>Malawi</option>
                              <option>Malaysia</option>
                              <option>Maldives</option>
                              <option>Mali</option>
                              <option>Malta</option>
                              <option>Marshall Islands</option>
                              <option>Martinique</option>
                              <option>Mauritania</option>
                              <option>Mauritius</option>
                              <option>Mayotte</option>
                              <option>Mexico</option>
                              <option>Micronesia, Federated States of</option>
                              <option>Moldova, Republic of</option>
                              <option>Monaco</option>
                              <option>Mongolia</option>
                              <option>Montserrat</option>
                              <option>Morocco</option>
                              <option>Mozambique</option>
                              <option>Myanmar</option>
                              <option>Namibia</option>
                              <option>Nauru</option>
                              <option>Nepal</option>
                              <option>Netherlands</option>
                              <option>Netherlands Antilles</option>
                              <option>New Caledonia</option>
                              <option>New Zealand</option>
                              <option>Nicaragua</option>
                              <option>Niger</option>
                              <option>Nigeria</option>
                              <option>Niue</option>
                              <option>Norfolk Island</option>
                              <option>Northern Mariana Islands</option>
                              <option>Norway</option>
                              <option>Oman</option>
                              <option>Pakistan</option>
                              <option>Palau</option>
                              <option>Panama</option>
                              <option>Papua New Guinea</option>
                              <option>Paraguay</option>
                              <option>Peru</option>
                              <option>Philippines</option>
                              <option>Pitcairn</option>
                              <option>Poland</option>
                              <option>Portugal</option>
                              <option>Puerto Rico</option>
                              <option>Qatar</option>
                              <option>Reunion</option>
                              <option>Romania</option>
                              <option>Russian Federation</option>
                              <option>Rwanda</option>
                              <option>Saint Kitts and Nevis</option>
                              <option>Saint Lucia</option>
                              <option>Saint Vincent and the Grenadines</option>
                              <option>Samoa</option>
                              <option>San Marino</option>
                              <option>Sao Tome and Principe</option>
                              <option>Saudi Arabia</option>
                              <option>Senegal</option>
                              <option>Seychelles</option>
                              <option>Sierra Leone</option>
                              <option>Singapore</option>
                              <option>Slovakia (Slovak Republic)</option>
                              <option>Slovenia</option>
                              <option>Solomon Islands</option>
                              <option>Somalia</option>
                              <option>South Africa</option>
                              <option>South Georgia and the South Sandwich Islands</option>
                              <option>Spain</option>
                              <option>Sri Lanka</option>
                              <option>St. Helena</option>
                              <option>St. Pierre and Miquelon</option>
                              <option>Sudan</option>
                              <option>Suriname</option>
                              <option>Svalbard and Jan Mayen Islands</option>
                              <option>Swaziland</option>
                              <option>Sweden</option>
                              <option>Switzerland</option>
                              <option>Syrian Arab Republic</option>
                              <option>Taiwan, Province of China</option>
                              <option>Tajikistan</option>
                              <option>Tanzania, United Republic of</option>
                              <option>Thailand</option>
                              <option>Togo</option>
                              <option>Tokelau</option>
                              <option>Tonga</option>
                              <option>Trinidad and Tobago</option>
                              <option>Tunisia</option>
                              <option>Turkey</option>
                              <option>Turkmenistan</option>
                              <option>Turks and Caicos Islands</option>
                              <option>Tuvalu</option>
                              <option>Uganda</option>
                              <option>Ukraine</option>
                              <option>United Arab Emirates</option>
                              <option>United Kingdom</option>
                              <option>United States</option>
                              <option>United States Minor Outlying Islands</option>
                              <option>Uruguay</option>
                              <option>Uzbekistan</option>
                              <option>Vanuatu</option>
                              <option>Venezuela</option>
                              <option>Vietnam</option>
                              <option>Virgin Islands (British)</option>
                              <option>Virgin Islands (U.S.)</option>
                              <option>Wallis and Futuna Islands</option>
                              <option>Western Sahara</option>
                              <option>Yemen</option>
                              <option>Yugoslavia</option>
                              <option>Zambia</option>
                              <option>Zimbabwe</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-6 col-sm-3">
                          <div class="form-group form-group">
                            <label class="ls text-uppercase text-600 font-weight-semi-bold mb-0" for="zipCode">Zip Code</label>
                            <input class="form-control" id="zipCode" placeholder="1234" type="text">
                          </div>
                        </div>
                        <div class="col-6 col-sm-3">
                          <div class="form-group">
                            <label class="ls text-uppercase text-600 font-weight-semi-bold mb-0" for="expDate">Exp Date</label>
                            <input class="form-control" id="expDate" placeholder="123" type="text">
                          </div>
                        </div>
                        <div class="col-6 col-sm-3">
                          <div class="form-group">
                            <label class="ls text-uppercase text-600 font-weight-semi-bold mb-0" for="cvv">CVV<span class="fa fa-question-circle ml-2" data-toggle="tooltip" data-placement="top" title="Card verification value"></span></label>
                            <input class="form-control" id="cvv" placeholder="123" maxlength="3" pattern="[0-9]{3}" type="text">
                          </div>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
            <div class="col-lg-4 pl-lg-2 mb-3">
              <div class="h-100 card">
                <div class="card-header">
                  <h5 class="mb-0">Billing Aside</h5>
                </div>
                <div class="bg-light card-body">
                  <select class="mb-3 custom-select" id="exampleCustomSelect" name="customSelect">
                    <option value="0">Annual Plan</option>
                    <option value="1" selected="">Monthly Plan</option>
                  </select>
                  <div class="d-flex justify-content-between fs--1 mb-1">
                    <p class="mb-0">Due in 30 days</p><span>$375.00</span>
                  </div>
                  <div class="d-flex justify-content-between fs--1 mb-1 text-success">
                    <p class="mb-0">Annual saving</p><span>$75.00/yr</span>
                  </div>
                  <hr>
                  <h5 class="d-flex justify-content-between"><span>Due today</span><span>$0.00</span></h5>
                  <p class="fs--1 text-600">Once you start your trial, you will have 30 days to use Falcon Premium for free. After 30 days you’ll be charged based on your selected plan.</p>
                  <button class="btn btn-primary btn-block" type="submit"><span class="fa fa-lock mr-2"></span>Start free trial</button>
                  <div class="text-center mt-2"><small class="d-inline-block">By continuing, you are agreeing to our subscriber <a href="/pages/billing#!">terms</a> and will be charged at the end of the trial. </small></div>
                </div>
              </div>
            </div>
          </div>
          <div class="card">
            <div class="card-header">
              <h5 class="mb-0">Frequently asked questions</h5>
            </div>
            <div class="card-body bg-light">
              <div class="row">
                <div class="col-lg-6">
                  <h5 class="fs-0">How does Falcon's pricing work?</h5>
                  <p class="fs--1">The free version of Falcon is available for teams of up to 15 people. Our Falcon Premium plans of 15 or fewer qualify for a small team discount. As your team grows to 20 users or more and gets more value out of Falcon, you'll get closer to our standard monthly price per seat. The price of a paid Falcon plan is tiered, starting in groups of 5 and 10 users, based on the number of people you have in your Team or Organization.</p>
                  <h5 class="fs-0">What forms of payment do you accept?</h5>
                  <p class="fs--1">You can purchase Falcon with any major credit card. For annual subscriptions, we can issue an invoice payable by bank transfer or check. Please contact us to arrange an invoice purchase. Monthly purchases must be paid for by credit card.</p>
                  <h5 class="fs-0">We need to add more people to our team. How will that be billed?</h5>
                  <p class="fs--1">You can add as many new teammates as you need before changing your subscription. We will subsequently ask you to correct your subscription to cover current usage.</p>
                  <h5 class="fs-0">How secure is Falcon?</h5>
                  <p class="fs--1 mb-lg-0">Protecting the data you trust to Falcon is our first priority. Falcon uses physical, procedural, and technical safeguards to preserve the integrity and security of your information. We regularly back up your data to prevent data loss and aid in recovery. Additionally, we host data in secure SSAE 16 / SOC1 certified data centers, implement firewalls and access restrictions on our servers to better protect your information, and work with third-party security researchers to ensure our practices are secure.</p>
                </div>
                <div class="col-lg-6">
                  <h5 class="fs-0">Will I be charged sales tax?</h5>
                  <p class="fs--1">As of May 2016, state and local sales tax will be applied to fees charged to customers with a billing address in the State of New York.</p>
                  <h5 class="fs-0">Do you offer discounts?</h5>
                  <p class="fs--1">We've built in discounts at each tier for teams smaller than 15 members. We also offer two months for free in exchange for an annual subscription.</p>
                  <h5 class="fs-0">Do you offer academic pricing?</h5>
                  <p class="fs--1">We're happy to work with student groups using Falcon. Contact Us</p>
                  <h5 class="fs-0">Is there an on-premise version of Falcon?</h5>
                  <p class="fs--1">We are passionate about the web. We don't plan to offer an internally hosted version of Falcon. We hope you trust us to provide a robust and secure service so you can do the work only your team can do.</p>
                  <h5 class="fs-0">What is your refund policy?</h5>
                  <p class="fs--1 mb-0">We do not offer refunds apart from exceptions listed below. If you cancel your plan before the next renewal cycle, you will retain access to paid features until the end of your subscription period. When your subscription expires, you will lose access to paid features and all data associated with those features. Exceptions to our refund policy: canceling within 48 hours of initial charge will result in a full refund. If you cancel within this timeframe, you will lose access to paid features and associated data immediately upon canceling.</p>
                </div>
              </div>
            </div>
            <div class="card-footer text-center py-3">
              <h6 class="fs-0 font-weight-normal">Have more questions?</h6><a class="btn btn-falcon-primary btn-sm" href="#" data-toggle="modal" data-target="#exampleModal">Ask us anything</a>
            </div>
          </div>
        </div>
      </div>
    </main>
    <!-- ===============================================-->
    <!--    End of Main Content-->
    <!-- ===============================================-->




    <!-- ===============================================-->
    <!--    JavaScripts-->
    <!-- ===============================================-->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.js"></script>
    <script src="assets/lib/stickyfilljs/stickyfill.min.js"></script>
    <script src="assets/lib/sticky-kit/sticky-kit.min.js"></script>
    <script src="assets/lib/is_js/is.min.js"></script>
    <script src="assets/lib/@fortawesome/all.min.js"></script>
    <script src="assets/js/theme.js"></script>

  </body>

</html>