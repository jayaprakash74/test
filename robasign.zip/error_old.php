<?php
    // Initialize the session
    session_start();
     
    // Check if the user is logged in, if not then redirect him to login page
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
        header("location: /");
        exit;
    }
?>

<!DOCTYPE html>
<html lang="en-US" dir="ltr">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- ===============================================-->
        <!--    Document Title-->
        <!-- ===============================================-->
        <title>Manual Verification | Robasign</title>
        <!-- ===============================================-->
        <!--    Favicons-->
        <!-- ===============================================-->
        <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/favicon-16x16.png">
        <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicons/favicon.ico">
        <link rel="manifest" href="assets/img/favicons/manifest.json">
        <meta name="msapplication-TileImage" content="assets/img/favicons/mstile-150x150.png">
        <meta name="theme-color" content="#ffffff">
        <!-- ===============================================-->
        <!--    Stylesheets-->
        <!-- ===============================================-->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700%7cPoppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
        <link href="assets/lib/jqvmap/jqvmap.min.css" rel="stylesheet">
        <link href="assets/lib/datatables-bs4/dataTables.bootstrap4.min.css" rel="stylesheet">
        <link href="assets/lib/datatables.net-responsive-bs4/responsive.bootstrap4.css" rel="stylesheet">
        <link href="assets/css/theme.css" rel="stylesheet">
    </head>
    <body>
        <!-- ===============================================-->
        <!--    Main Content-->
        <!-- ===============================================-->
        <main class="main" id="top">
            <div class="container-fluid">
                <?php include 'menu.php'; ?>
                <div class="content">
                    <?php include 'header_bar.php';?>
                    <div class="card-body p-0">
					<div id="successMessages" class="alert alert-success alert-dismissible" style="display:none;" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<div id="messages_content"><?php echo"Application Updated Succesfully"; ?> <?php //echo $last_id; ?></div>
					</div>
                        <div class="dashboard-data-table">
                            <table class="table table-sm mb-0 table-dashboard fs--1 data-table border-bottom" data-options='{"responsive":false,"pagingType":"simple","lengthChange":false,"searching":false,"pageLength":8,"columnDefs":[{"targets":[0,6],"orderable":false}],"language":{"info":"_START_ to _END_ Items of _TOTAL_ — <a href=\"#!\" class=\"font-weight-semi-bold\"> view all <span class=\"fas fa-angle-right\" data-fa-transform=\"down-1\"></span> </a>"},"dom":"<&#39;row mx-1&#39;<&#39;col-sm-12 col-md-6&#39;l><&#39;col-sm-12 col-md-6&#39;f>><&#39;table-responsive&#39;tr><&#39;row no-gutters px-1 py-3 align-items-center&#39;<&#39;col pl-3&#39;i><&#39;col-auto pr-3&#39;p>>"}'>
                                <thead class="bg-200 text-900">
                                    <tr>
                                        <th class="no-sort pr-1 align-middle">
                                            <div class="custom-control custom-checkbox ml-3">
                                                <input class="custom-control-input checkbox-bulk-select" id="checkbox-bulk-purchases-select" type="checkbox" data-checkbox-body="#purchases" data-checkbox-actions="#purchases-actions" data-checkbox-replaced-element="#dashboard-actions" />
                                                <label class="custom-control-label" for="checkbox-bulk-purchases-select"></label>
                                            </div>
                                        </th>
                                        <th class="sort pr-1 align-middle">Application ID</th>
                                        <th class="sort pr-1 align-middle">File Name</th>
										<th class="no-sort pr-1 align-middle">View Files</th>
										<th class="no-sort pr-1 align-middle">Update Status</th>
                                    </tr>
                                </thead>
								<tbody id="purchases">
								
								<?php

									// Include config file
									require_once "config.php";
									
									$user_id = trim($_SESSION['id']);
									
									$app_id = $_GET['q'];
									
									$stmt = "SELECT * FROM verificationstatus WHERE DocumentStatus = 'Verification Failed' AND ApplicationID = '$app_id'";
									
									$result = mysqli_query($link, $stmt);
									
									if (mysqli_num_rows($result) > 0) {
										while($row = mysqli_fetch_assoc($result)) {
											?>
											<tr class="btn-reveal-trigger">
												<td class="align-middle">
													<div class="custom-control custom-checkbox ml-3">
														<input class="custom-control-input checkbox-bulk-select-target" type="checkbox" id="checkbox-3" />
														<label class="custom-control-label" for="checkbox-3"></label>
													</div>
												</td>
												<td class="align-middle"><?php echo $row["ApplicationID"]; ?></td>
											<td class="align-middle fs-0"><span class="badge badge rounded-capsule badge-danger"><?php echo $row["DocumentStatus"]?><span class="ml-1 fas fa-exclamation-triangle" data-fa-transform="shrink-2"></span></span>
                                            </td>
											<td class="align-middle">
											
											
											<?php
											$code = $row["DocCode"];
											if ($row["DocCode"] == "BS1") {
												echo '<button class="btn btn-outline-success rounded-capsule mr-1 mb-1" onclick = "openPdf()" type="button" role="button">Bankstatement1</button>';
											} elseif ($row["DocCode"] == "BS2") {
												echo '<button class="btn btn-outline-success rounded-capsule mr-1 mb-1" onclick = "openPdf()" type="button" role="button">Bankstatement2</button>';
											} elseif ($row["DocCode"] == "BS3") {
												echo '<button class="btn btn-outline-success rounded-capsule mr-1 mb-1" onclick = "openPdf()" type="button" role="button">Bankstatement3</button>';
											} elseif (preg_match("/PS/", $row["DocCode"])) {
											?>

											
											<button class="btn btn-outline-success rounded-capsule mr-1 mb-1" onclick = "openPdf1()" type="button" role="button">
											
											<?php
											if ($row["DocCode"] == "PS1") {
												echo "Payslip1";
											} elseif ($row["DocCode"] == "PS2") {
												echo "Payslip2";
											} elseif ($row["DocCode"] == "PS3") {
												echo "Payslip3";
											}
											}
											?>
											
											</button>
											</td>
											<td class="align-middle">
												<button class="btn btn-outline-success rounded-capsule mr-1 mb-1" id="verifySuccess" type="button" role="button">Mark as Verification Successful</button><br>
												<button class="btn btn-outline-danger rounded-capsule mr-1 mb-1" id="verifyFailure" type="button" role="button">Mark as Verification Failure</button>
											</td>
											</tr>
											
											<?php
										}
									} else { ?>
										<a href="event-create"><button class="btn btn-primary mr-1 mb-1" type="button">
											<span class="fas fa-plus mr-1" data-fa-transform="shrink-3"></span>Create Application
											</button>
										</a>
									<?php
									}
									
									
								?>
                                </tbody>
                            </table>
								<button class="btn btn-outline-danger rounded-capsule mr-1 mb-1" onclick="closeFrame()" style="display:none" type="button" id="closeBtn" role="button">Close</button>
								<iframe id="myFrame" style="display:none" width="90%" height="500"></iframe>
								<div class="mb-10"></div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <!-- ===============================================-->
        <!--    End of Main Content-->
        <!-- ===============================================-->
		
		<script type="text/javascript">
			function openPdf() {
var omyFrame = document.getElementById("myFrame");
var closeBtn = document.getElementById("closeBtn");
omyFrame.style.display="block";
closeBtn.style.display="block";

<?php 

$stmt2 = "SELECT * FROM rs_applications WHERE id = '$app_id'"; 
$result2 = mysqli_query($link, $stmt2);
global $bs1, $bs2, $bs3, $ps1, $ps2, $ps3;
if (mysqli_num_rows($result2) > 0) {
while($row2 = mysqli_fetch_assoc($result)) {
$bs1 = $row["bankstatement1"];
$bs2 = $row["bankstatement2"];
$bs3 = $row["bankstatement3"];
$ps1 = $row["payslip1"];
$ps2 = $row["payslip2"];
$ps3 = $row["payslip3"];

echo '
omyFrame.src =".if (preg_match("/PS1/", $code)) { 'Main Folder/Needs Attention Applications/'.$bs1; } 
elseif (preg_match("/PS2/", $code)) { echo 'Main Folder/Needs Attention Applications/'.$bs2; } 
elseif (preg_match("/PS3/", $code)) { echo 'Main Folder/Needs Attention Applications/'.$bs3; }";'
<?php }}?>

			}
function openPdf1() {
var omyFrame = document.getElementById("myFrame");
var closeBtn = document.getElementById("closeBtn");
omyFrame.style.display="block";
closeBtn.style.display="block";
omyFrame.src = "<?php if (preg_match("/PS1/", $code)) { echo 'Main Folder/Needs Attention Applications/'.$ps1; } elseif (preg_match("/PS2/", $code)) { echo 'Main Folder/Needs Attention Applications/'.$ps2; } elseif (preg_match("/PS3/", $code)) { echo 'Main Folder/Needs Attention Applications/'.$ps3; } ?>";

}

function closeFrame() {
var omyFrame = document.getElementById("myFrame");
var closeBtn = document.getElementById("closeBtn");
omyFrame.style.display="none";
closeBtn.style.display="none";
omyFrame.src = "";
}
		</script>

        <!-- ===============================================-->
        <!--    JavaScripts-->
        <!-- ===============================================-->
        <script src="https://canvasjs.com/assets/script/jquery-1.11.1.min.js"></script>
        <script src="https://canvasjs.com/assets/script/jquery.canvasjs.min.js"></script>
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.js"></script>
        <script src="assets/lib/stickyfilljs/stickyfill.min.js"></script>
        <script src="assets/lib/sticky-kit/sticky-kit.min.js"></script>
        <script src="assets/lib/is_js/is.min.js"></script>
        <script src="assets/lib/@fortawesome/all.min.js"></script>
        <script src="assets/lib/chart.js/Chart.min.js"></script>
        <script src="assets/lib/jqvmap/jquery.vmap.js"></script>
        <script src="assets/lib/jqvmap/maps/jquery.vmap.world.js" charset="utf-8"></script>
        <script src="assets/lib/jqvmap/maps/jquery.vmap.usa.js" charset="utf-8"></script>
        <script src="assets/lib/datatables/js/jquery.dataTables.min.js"></script>
        <script src="assets/lib/datatables-bs4/dataTables.bootstrap4.min.js"></script>
        <script src="assets/lib/datatables.net-responsive/dataTables.responsive.js"></script>
        <script src="assets/lib/datatables.net-responsive-bs4/responsive.bootstrap4.js"></script>
        <script src="assets/lib/chart.js/Chart.min.js"></script>
        <script src="assets/js/theme.js"></script>
		
		<script>
		$(document).on("click", "#verifySuccess", function() { 
		var id = <?php echo $app_id; ?>;
		$.ajax({
			url: "statusUpdate.php",
			type: "POST",
			cache: false,
			//contentType: 'application/json',
			data:{
				id: id,
				status: "success"
			},
			success: function(dataResult){
				var dataResult = JSON.parse(dataResult);
				alert(dataResult);
				if(dataResult.statusCode==200){
					$('#successMessages').show();
					alert(dataResult);					
				}
			}
		});
	});
		</script>
		
    </body>
</html>
