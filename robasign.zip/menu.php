<nav class="navbar navbar-vertical navbar-expand-xl navbar-light navbar-glass">
    <a class="navbar-brand text-left" href="index">
        <div class="d-flex align-items-center py-3"><img class="mr-2" src="assets/img/illustrations/falcon.png" alt="" width="40" /><span class="text-sans-serif">Robasign</span>
        </div>
    </a>
    <div class="collapse navbar-collapse" id="navbarVerticalCollapse">
        <ul class="navbar-nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="dashboard" role="button">
                    <div class="d-flex align-items-center"><span class="nav-link-icon"><span class="fas fa-chart-pie"></span></span><span>Dashboard</span>
                    </div>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="event-create" role="button">
                    <div class="d-flex align-items-center"><span class="nav-link-icon"><span class="fas fa-plus"></span></span><span>New</span>
                    </div>
                </a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="modify" role="button">
                    <div class="d-flex align-items-center"><span class="nav-link-icon"><span class="fas fa-pencil-alt"></span></span><span>Modify</span>
                    </div>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#" role="button">
                    <div class="d-flex align-items-center"><span class="nav-link-icon"><span class="fas fa-crosshairs"></span></span><span>Track</span>
                    </div>
                </a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="notifications" role="button">
                    <div class="d-flex align-items-center"><span class="nav-link-icon"><span class="fas fa-bell"></span></span><span>Notifications</span>
                    </div>
                </a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="#" role="button">
                    <div class="d-flex align-items-center"><span class="nav-link-icon"><span class="fas fa-file"></span></span><span>Management Report</span>
                    </div>
                </a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="#" role="button">
                    <div class="d-flex align-items-center"><span class="nav-link-icon"><span class="fas fa-calendar"></span></span><span>Timeline</span>
                    </div>
                </a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="faq" role="button">
                    <div class="d-flex align-items-center"><span class="nav-link-icon"><span class="fas fa-question-circle"></span></span><span>Faq</span>
                    </div>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="invoice" role="button">
                    <div class="d-flex align-items-center"><span class="nav-link-icon"><span class="fas fa-file-invoice"></span></span><span>Invoice</span>
                    </div>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="pricing" role="button">
                    <div class="d-flex align-items-center"><span class="nav-link-icon"><span class="fas fa-money-check"></span></span><span>Pricing</span>
                    </div>
                </a>
            </li>
			<li class="nav-item">
                <a class="nav-link" href="billing" role="button">
                    <div class="d-flex align-items-center"><span class="nav-link-icon"><span class="fas fa-file-invoice-dollar"></span></span><span>Billing</span>
                    </div>
                </a>
            </li>
            <!--<li class="nav-item">
                <a class="nav-link" href="profile" role="button">
                    <div class="d-flex align-items-center"><span class="nav-link-icon"><span class="fa fa-user"></span></span><span>Profile</span>
                    </div>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="settings" role="button">
                    <div class="d-flex align-items-center"><span class="nav-link-icon"><span class="fa fa-gear"></span></span><span>Settings</span>
                    </div>
                </a>
            </li>-->
        </ul>
    </div>
</nav>