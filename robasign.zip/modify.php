<?php
    // Initialize the session
    session_start();
     
    // Check if the user is logged in, if not then redirect him to login page
    if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
        header("location: /");
        exit;
    }
	
	// Include config file
	require_once "config.php";
	
?>

<!DOCTYPE html>
<html lang="en-US" dir="ltr">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <!-- ===============================================-->
        <!--    Document Title-->
        <!-- ===============================================-->
        <title>Modify Application | Robasign</title>
        <!-- ===============================================-->
        <!--    Favicons-->
        <!-- ===============================================-->
        <link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/apple-touch-icon.png">
        <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/favicon-32x32.png">
        <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/favicon-16x16.png">
        <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicons/favicon.ico">
        <link rel="manifest" href="assets/img/favicons/manifest.json">
        <meta name="msapplication-TileImage" content="assets/img/favicons/mstile-150x150.png">
        <meta name="theme-color" content="#ffffff">
        <!-- ===============================================-->
        <!--    Stylesheets-->
        <!-- ===============================================-->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,500,600,700%7cPoppins:100,200,300,400,500,600,700,800,900" rel="stylesheet">
        <link href="assets/lib/jqvmap/jqvmap.min.css" rel="stylesheet">
        <link href="assets/lib/datatables-bs4/dataTables.bootstrap4.min.css" rel="stylesheet">
        <link href="assets/lib/datatables.net-responsive-bs4/responsive.bootstrap4.css" rel="stylesheet">
        <link href="assets/css/theme.css" rel="stylesheet">
    </head>
    <body>
        <!-- ===============================================-->
        <!--    Main Content-->
        <!-- ===============================================-->
        <main class="main" id="top">
            <div class="container-fluid">
                <?php include 'menu.php'; ?>
                <div class="content">
                    <?php include 'header_bar.php';?>
                    <div class="card-body p-0">
                        <div class="dashboard-data-table">
                            <table class="table table-sm mb-0 table-dashboard fs--1 data-table border-bottom" data-options='{"responsive":false,"pagingType":"simple","lengthChange":false,"searching":true,"pageLength":10,"columnDefs":[{"targets":[0,6],"orderable":false}],"language":{"info":"_START_ to _END_ Items of _TOTAL_ — <a href=\"#!\" class=\"font-weight-semi-bold\"> view all <span class=\"fas fa-angle-right\" data-fa-transform=\"down-1\"></span> </a>"},"dom":"<&#39;row mx-1&#39;<&#39;col-sm-12 col-md-6&#39;l><&#39;col-sm-12 col-md-6&#39;f>><&#39;table-responsive&#39;tr><&#39;row no-gutters px-1 py-3 align-items-center&#39;<&#39;col pl-3&#39;i><&#39;col-auto pr-3&#39;p>>"}'>
                                <thead class="bg-200 text-900">
                                    <tr>
                                        <th class="no-sort pr-1 align-middle">
                                            <div class="custom-control custom-checkbox ml-3">
                                                <input class="custom-control-input checkbox-bulk-select" id="checkbox-bulk-purchases-select" type="checkbox" data-checkbox-body="#purchases" data-checkbox-actions="#purchases-actions" data-checkbox-replaced-element="#dashboard-actions" />
                                                <label class="custom-control-label" for="checkbox-bulk-purchases-select"></label>
                                            </div>
                                        </th>
                                        <th class="sort pr-1 align-middle">Application ID</th>
                                        <th class="sort pr-1 align-middle">Customer Name</th>
                                        <th class="sort pr-1 align-middle">Email</th>
                                        <th class="sort pr-1 align-middle">Type of Verification</th>
                                        <th class="sort pr-1 align-middle text-center">Status of Application</th>
                                        <th class="sort pr-1 align-middle text-right">Stage of Verification</th>
                                        <th class="no-sort pr-1 align-middle"></th>
                                    </tr>
                                </thead>
								<tbody id="purchases">
								
								<?php

									$user_id = trim($_SESSION['id']);
									
									$stmt = "SELECT * FROM rs_applications WHERE rs_users_id = '$user_id' AND application_status = 'Not Submitted' ORDER BY id DESC";
									
									$result = mysqli_query($link, $stmt);
									
									if (mysqli_num_rows($result) > 0) {
										while($row = mysqli_fetch_assoc($result)) {
											?>
											<tr class="btn-reveal-trigger">
												<td class="align-middle">
												<div class="custom-control custom-checkbox ml-3">
													<input class="custom-control-input checkbox-bulk-select-target" type="checkbox" id="checkbox-3" />
													<label class="custom-control-label" for="checkbox-3"></label>
												</div>
											</td>
											<td class="align-middle"><?php echo $row["id"]; ?></td>
                                        <th class="align-middle"><a href="event-edit?q=<?php echo $row["id"]; ?>&app_id=<?php echo md5($row["id"]); ?>"><?php echo $row["firstname"]; ?> <?php echo $row["lastname"]; ?></a></th>
                                        <td class="align-middle"><?php echo $row["email"]; ?></td>
                                        <td class="align-middle"><?php echo $row["product_type"]; ?></td>
                                        <?php 
											if ($row["application_status"] == "Not Submitted") {
										?>
											<td class="align-middle text-center fs-0"><span class="badge badge rounded-capsule badge-soft-secondary"><?php echo $row["application_status"]?><span class="ml-1 fas fa-stop" data-fa-transform="shrink-2"></span></span>
											</td>
										<?php 
											} elseif ($row["application_status"] == "InProgress") {
										?>		
											<td class="align-middle text-center fs-0"><span class="badge badge rounded-capsule badge-warning"><?php echo $row["application_status"]?><span class="ml-1 fas fa-spinner" data-fa-transform="shrink-2"></span></span>
											</td>
										<?php		
											} elseif ($row["application_status"] == "Verification Successful") {
										?>
											<td class="align-middle text-center fs-0"><span class="badge badge rounded-capsule badge-soft-success"><?php echo $row["application_status"]?><span class="ml-1 fas fa-check" data-fa-transform="shrink-2"></span></span>
                                            </td>
										<?php 
											} elseif ($row["application_status"] == "Verification Failed") {
										?>
											<td class="align-middle text-center fs-0"><span class="badge badge rounded-capsule badge-danger"><?php echo $row["application_status"]?><span class="ml-1 fas fa-check" data-fa-transform="shrink-2"></span></span>
                                            </td>
										<?php 
											} 
										?>
                                        <td class="align-middle text-right">0/7</td>
                                        <td class="align-middle white-space-nowrap">
                                            <div class="dropdown text-sans-serif">
                                                <button class="btn btn-link text-600 btn-sm dropdown-toggle btn-reveal mr-3" type="button" id="dropdown3" data-toggle="dropdown" data-boundary="viewport" aria-haspopup="true" aria-expanded="false"><span class="fas fa-ellipsis-h fs--1"></span></button>
                                                <div class="dropdown-menu dropdown-menu-right border py-0" aria-labelledby="dropdown3">
                                                    <div class="bg-white py-2">
                                                        <a class="dropdown-item" href="#!">View</a><a class="dropdown-item" href="event-edit">Edit</a><a class="dropdown-item" href="#!">Refund</a>
                                                        <div class="dropdown-divider"></div>
                                                        <a class="dropdown-item text-warning" href="#!">Archive</a><a class="dropdown-item text-danger" href="#!">Delete</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
											
											<?php
										}
									} else {?>
										<a href="event-create"><button class="btn btn-primary mr-1 mb-1" type="button">
											<span class="fas fa-plus mr-1" data-fa-transform="shrink-3"></span>Create Application
											</button>
										</a>
									<?php
									}
									
									mysqli_close($link);
									
								?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <!-- ===============================================-->
        <!--    End of Main Content-->
        <!-- ===============================================-->
        <!-- ===============================================-->
        <!--    JavaScripts-->
        <!-- ===============================================-->
        <script src="https://canvasjs.com/assets/script/jquery-1.11.1.min.js"></script>
        <script src="https://canvasjs.com/assets/script/jquery.canvasjs.min.js"></script>
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.js"></script>
        <script src="assets/lib/stickyfilljs/stickyfill.min.js"></script>
        <script src="assets/lib/sticky-kit/sticky-kit.min.js"></script>
        <script src="assets/lib/is_js/is.min.js"></script>
        <script src="assets/lib/@fortawesome/all.min.js"></script>
        <script src="assets/lib/chart.js/Chart.min.js"></script>
        <script src="assets/lib/jqvmap/jquery.vmap.js"></script>
        <script src="assets/lib/jqvmap/maps/jquery.vmap.world.js" charset="utf-8"></script>
        <script src="assets/lib/jqvmap/maps/jquery.vmap.usa.js" charset="utf-8"></script>
        <script src="assets/lib/datatables/js/jquery.dataTables.min.js"></script>
        <script src="assets/lib/datatables-bs4/dataTables.bootstrap4.min.js"></script>
        <script src="assets/lib/datatables.net-responsive/dataTables.responsive.js"></script>
        <script src="assets/lib/datatables.net-responsive-bs4/responsive.bootstrap4.js"></script>
        <script src="assets/lib/chart.js/Chart.min.js"></script>
        <script src="assets/js/theme.js"></script>
		
		<script>
			
		</script>
		
    </body>
</html>
