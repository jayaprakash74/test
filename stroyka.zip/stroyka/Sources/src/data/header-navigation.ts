import { NavigationLink } from '../app/shared/interfaces/navigation-link';

export const navigation: NavigationLink[] = [
    {label: 'Home', url: '/compact/home', menu: {
        type: 'menu',
        items: [
            //{label: 'Home 1', url: '/classic'},
            //{label: 'Home 2', url: '/compact'}
        ]
    }},
    {label: 'Megamenu', url: './shop', menu: {
        type: 'megamenu',
        size: 'nl',
        columns: [
            {size: 4, items: [
                {label: 'Mobiles', url: './shop', items: [
                    {label: 'Mi', url: './shop'},
                    {label: 'Realme', url: './shop'},
                    {label: 'Samsung', url: './shop'},
                    {label: 'Infinix', url: './shop'},
                    {label: 'OPPO', url: './shop'},
                    {label: 'Apple', url: './shop'},
                    {label: 'Vivo', url: './shop'},
                    {label: 'Honor', url: './shop'},
                    {label: 'Asus', url: './shop'},
                    {label: 'Pixel 3a | 3a XL', url: './shop'},
                    {label: 'Realme', url: './shop'}
                ]},
                {label: 'Mobile Accessories', url: './shop', items: [
                    {label: 'Mobile Cases', url: './shop'},
                    {label: 'Headphones & Headsets', url: './shop'},
                    {label: 'Power Banks', url: './shop'},
                    {label: 'Screenguards', url: './shop'},
                    {label: 'Memory Cards', url: './shop'},
                    {label: 'Smart Headphones', url: './shop'},
                    {label: 'Mobile Cables', url: './shop'},
                    {label: 'Mobile Chargers', url: './shop'},
                    {label: 'Mobile Holders', url: './shop'}
                ]}
            ]},
            {size: 4, items: [
				{label: 'Smart Wearable Tech', url: './shop', items: [
                    {label: 'Smart Watches', url: './shop'},
                    {label: 'Smart Glasses (VR)', url: './shop'},
                    {label: 'Smart Bands', url: './shop'}
                ]},
				{label: 'Health Care Appliances', url: './shop', items: [
                    {label: 'Bp Monitors', url: './shop'},
                    {label: 'Weighing Scale', url: './shop'}
                ]},
				{label: 'Tablets', url: './shop', items: [
                    {label: 'Apple', url: './shop'},
                    {label: 'IBall', url: './shop'},
					{label: 'Kindle', url: './shop'},
					{label: 'Lava', url: './shop'},
					{label: 'Micromax', url: './shop'},
					{label: 'Samsung', url: './shop'}
                ]}
            ]},
			{size: 4, items: [
				{label: 'Laptops', url: './shop', items: [
                    {label: 'Gaming Laptops', url: './shop'}
				]},
				{label: 'Desktop PCs', url: './shop', items: [
                ]},
				{label: 'Gaming Accessories', url: './shop', items: [
                ]},
				{label: 'Computer Accessories', url: './shop', items: [
					{label: 'External Hard Disks', url: './shop'},
					{label: 'Pendrives', url: './shop'},
					{label: 'Laptop Skins & Decals', url: './shop'},
					{label: 'Laptop Bags', url: './shop'},
					{label: 'Mouse', url: './shop'}
                ]},
				{label: 'Computer Peripherals', url: './shop', items: [
					{label: 'Printers & Ink Cartridges', url: './shop'},
					{label: 'Monitors', url: './shop'},
					{label: 'Tablets', url: './shop'},
					{label: 'Apple iPads', url: './shop'}
                ]}
			]}
        ]
    }},
    /*{label: 'Shop', url: './shop', menu: {
        type: 'menu',
        items: [
            {label: 'Shop Grid', url: './shop', items: [
                {label: '3 Columns Sidebar', url: './shop/category-grid-3-columns-sidebar'},
                {label: '4 Columns Full',    url: './shop/category-grid-4-columns-full'},
                {label: '5 Columns Full',    url: './shop/category-grid-5-columns-full'}
            ]},
            {label: 'Shop List', url: './shop/category-list'},
            {label: 'Shop Right Sidebar', url: './shop/category-right-sidebar'},
            {label: 'Product', url: './shop/product', items: [
                {label: 'Product', url: './shop/product'},
                {label: 'Product Alt', url: './shop/product-columnar'},
                {label: 'Product Sidebar', url: './shop/product-sidebar'}
            ]},
            {label: 'Cart', url: './shop/cart'},
            {label: 'Checkout', url: './shop/checkout'},
            {label: 'Wishlist', url: './shop/wishlist'},
            {label: 'Compare', url: './shop/compare'},
            {label: 'Track Order', url: './shop/track-order'},
        ]
    }},
    {label: 'Account', url: './account', menu: {
        type: 'menu',
        items: [
            {label: 'Login',           url: './account/login'},
            {label: 'Dashboard',       url: './account/dashboard'},
            {label: 'Edit Profile',    url: './account/profile'},
            {label: 'Order History',   url: './account/orders'},
            {label: 'Address Book',    url: './account/addresses'},
            {label: 'Change Password', url: './account/password'}
        ]
    }},
    {label: 'Blog', url: './blog', menu: {
        type: 'menu',
        items: [
            {label: 'Blog Classic',         url: './blog/category-classic'},
            {label: 'Blog Grid',            url: './blog/category-grid'},
            {label: 'Blog List',            url: './blog/category-list'},
            {label: 'Blog Left Sidebar',    url: './blog/category-left-sidebar'},
            {label: 'Post Page',            url: './blog/post-classic'},
            {label: 'Post Without Sidebar', url: './blog/post-full'}
        ]
    }},*/
    {label: 'Pages', url: './site', menu: {
        type: 'menu',
        items: [
            {label: 'About Us',             url: './site/about-us'},
            {label: 'Contact Us',           url: './site/contact-us'},
            {label: 'Contact Us Alt',       url: './site/contact-us-alt'},
            {label: '404',                  url: './site/not-found'},
            {label: 'Terms And Conditions', url: './site/terms'},
            {label: 'FAQ',                  url: './site/faq'},
            {label: 'Components',           url: './site/components'},
            {label: 'Typography',           url: './site/typography'}
        ]
    }},
    /*{label: 'Buy Theme', url: 'https://themeforest.net/item/stroyka-tools-store-angular-7-template/23523630', external: true}*/
];
