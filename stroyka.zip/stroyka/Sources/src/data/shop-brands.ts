import { Brand } from '../app/shared/interfaces/brand';

export const brands: Brand[] = [
    {image: 'assets/images/logos/logo-1.jpg'},
    {image: 'assets/images/logos/logo-2.jpg'},
    {image: 'assets/images/logos/logo-3.jpg'},
    {image: 'assets/images/logos/logo-4.jpg'},
    {image: 'assets/images/logos/logo-5.jpg'},
    {image: 'assets/images/logos/logo-6.jpg'},
    {image: 'assets/images/logos/logo-7.jpg'}
];
