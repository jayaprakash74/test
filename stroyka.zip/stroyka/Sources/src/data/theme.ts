export const theme = {
    name: 'Telefonedeal',
    author: {
        name: 'ADZGlobe',
        profile_url: 'https://www.adzglobe.com'
    }
};
