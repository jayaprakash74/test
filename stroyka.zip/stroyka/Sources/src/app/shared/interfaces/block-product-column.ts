export interface BlockProductColumn {
    header: string;
    products: any[];
}
