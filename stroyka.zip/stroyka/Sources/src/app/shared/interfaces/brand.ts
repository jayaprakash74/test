export interface Brand {
    image: string;
}
