export interface Category {
    name: string;
    url: string;
    children?: Category[];
}
